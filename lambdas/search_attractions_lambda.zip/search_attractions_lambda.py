import json
import boto3
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from decimal import Decimal

def decimal_default(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Configure comprehensive logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# Create formatter for detailed logs
formatter = logging.Formatter('[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s')
# Ensure handler exists
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def lambda_handler(event, context):
    """
    MCP-compatible Lambda function for attraction search
    
    Expected input format:
    {
        "body": "{\"destination\": \"Paris\", \"date\": \"2024-12-15\", \"category\": \"museums\", \"budget_range\": \"medium\"}"
    }
    """
    
    # Log the incoming event for debugging
    logger.info("=== LAMBDA INVOCATION START ===")
    logger.info(f"Raw event received: {json.dumps(event, default=str)}")
    logger.info(f"Context: {context}")
    logger.info(f"Function name: {context.function_name if context else 'Unknown'}")
    logger.info(f"Request ID: {context.aws_request_id if context else 'Unknown'}")
    logger.info(f"Remaining time: {context.get_remaining_time_in_millis() if context else 'Unknown'}ms")
    
    try:
        # Parse the incoming event with detailed logging
        logger.info("Step 1: Parsing incoming event...")
        
        # Handle different event formats - API Gateway vs Direct Lambda invocation
        body = {}
        
        # Check if this is a direct Lambda invocation (parameters directly in event)
        if 'destination' in event and 'date' in event:
            logger.info("Direct Lambda invocation detected - using event as body")
            body = event
            logger.info(f"Direct invocation body: {body}")
        
        # Check if this is API Gateway format (body field)
        elif event.get('body') is not None:
            if isinstance(event.get('body'), str):
                logger.info(f"API Gateway format - Event body is string: {event['body']}")
                if event['body'].strip():  # Check if not empty string
                    body = json.loads(event['body'])
                    logger.info(f"Parsed API Gateway body: {body}")
                else:
                    logger.warning("Event body is empty string")
                    body = {}
            elif isinstance(event.get('body'), dict):
                logger.info("API Gateway format - Event body is already a dict")
                body = event['body']
            else:
                logger.warning(f"Event body is unexpected type: {type(event.get('body'))}")
                body = event.get('body', {}) if event.get('body') is not None else {}
        
        # No body found in either format
        else:
            logger.warning("No request body found in either direct or API Gateway format")
            body = {}
        
        # Extract attraction search parameters with detailed logging
        logger.info("Step 2: Extracting search parameters...")
        
        destination = body.get('destination', '')
        date = body.get('date', '')
        category = body.get('category', 'all')
        budget_range = body.get('budget_range', 'medium')
        duration = body.get('duration', 'half_day')  # half_day, full_day, multi_day
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - destination: '{destination}'")
        logger.info(f"  - date: '{date}'")
        logger.info(f"  - category: '{category}'")
        logger.info(f"  - budget_range: '{budget_range}'")
        logger.info(f"  - duration: '{duration}'")
        
        logger.info(f"Attraction search request: {destination}, {date}, {category} category, {budget_range} budget")
        
        # Validate required parameters with detailed logging
        logger.info("Step 3: Validating required parameters...")
        
        missing_params = []
        if not destination:
            missing_params.append('destination')
        if not date:
            missing_params.append('date')
            
        if missing_params:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameters',
                    'missing': missing_params,
                    'required': ['destination', 'date'],
                    'received': body
                }, default=decimal_default)
            }
            logger.error(f"Validation failed - missing parameters: {missing_params}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
        logger.info("✅ All required parameters validated successfully")
        
        # Validate date format
        logger.info("Step 4: Validating date format...")
        
        try:
            logger.info(f"Parsing date: {date}")
            visit_date = datetime.strptime(date, '%Y-%m-%d')
            logger.info(f"Parsed date: {visit_date}")
            
            # Check if date is in the past
            today = datetime.now().date()
            if visit_date.date() < today:
                logger.warning(f"Visit date {date} is in the past")
            
        except ValueError as e:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Invalid date format. Use YYYY-MM-DD',
                    'details': str(e),
                    'received_date': date
                }, default=decimal_default)
            }
            logger.error(f"Invalid date format: {date}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
        
        # Search attractions from DynamoDB synthetic data
        logger.info("Step 5: Starting attraction search from DynamoDB...")
        attractions = search_attractions_from_dynamodb(destination, date, category, budget_range, duration)
        logger.info(f"Attraction search completed - found {len(attractions)} attractions")
        
        # Return MCP-compatible response
        response_body = {
            'attractions': attractions,
            'search_params': {
                'destination': destination,
                'date': date,
                'category': category,
                'budget_range': budget_range,
                'duration': duration
            },
            'total_results': len(attractions)
        }
        
        response = {
            'statusCode': 200,
            'body': json.dumps(response_body, default=decimal_default)
        }
        
        logger.info(f"✅ Attraction search completed successfully: {len(attractions)} results found")
        logger.info(f"Response body size: {len(json.dumps(response_body, default=decimal_default))} characters")
        logger.info("=== LAMBDA INVOCATION SUCCESS ===")
        return response
        
    except json.JSONDecodeError as e:
        error_response = {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body',
                'details': str(e),
                'received_body': event.get('body', 'No body')
            }, default=decimal_default)
        }
        logger.error(f"❌ JSON decode error: {str(e)}")
        logger.error(f"Raw body that failed to parse: {event.get('body', 'No body')}")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (JSON) ===")
        return error_response
    
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full exception traceback:")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (EXCEPTION) ===")
        return error_response

def search_attractions_from_dynamodb(destination: str, date: str, category: str, budget_range: str, duration: str) -> List[Dict]:
    """
    Search attractions from DynamoDB synthetic data
    """
    logger.info(f"=== DYNAMODB SEARCH START ===")
    logger.info(f"Search parameters: destination={destination}, category={category}, budget={budget_range}, duration={duration}")
    
    # Initialize DynamoDB resource
    logger.info("Initializing DynamoDB resource...")
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('exec-synthetic-attractions')
        logger.info("✅ DynamoDB resource initialized successfully")
        logger.info(f"Table name: {table.table_name}")
        
        # Validate table exists and is accessible
        logger.debug("Validating table accessibility...")
        table_status = table.table_status
        logger.info(f"Table status: {table_status}")
        
        if table_status != 'ACTIVE':
            logger.warning(f"⚠️ Table status is {table_status}, not ACTIVE")
        
    except Exception as e:
        logger.error(f"❌ Failed to initialize DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB initialization error:")
        raise e
    
    try:
        # Query using GSI for city
        logger.info(f"Querying DynamoDB for city: {destination}")
        logger.info("Using CityIndex GSI...")
        
        query_params = {
            'IndexName': 'CityIndex',
            'KeyConditionExpression': 'city = :city',
            'ExpressionAttributeValues': {
                ':city': destination
            }
        }
        logger.info(f"Query parameters: {query_params}")
        
        response = table.query(**query_params)
        logger.info(f"DynamoDB query response: Count={response.get('Count', 0)}, ScannedCount={response.get('ScannedCount', 0)}")
        
        attractions = response.get('Items', [])
        logger.info(f"Found {len(attractions)} attractions for city: {destination}")
        
        # If no attractions found for exact city, get sample attractions and modify them
        if not attractions:
            logger.warning(f"No attractions found for {destination}, falling back to sample data")
            logger.info("Performing table scan for sample attractions...")
            
            scan_response = table.scan(Limit=15)
            attractions = scan_response.get('Items', [])
            logger.info(f"Scan returned {len(attractions)} sample attractions")
            
            # Modify sample attractions to match the search criteria
            logger.info(f"Modifying sample attractions to match destination: {destination}")
            for attraction in attractions:
                original_city = attraction.get('city', 'Unknown')
                attraction['city'] = destination
                logger.debug(f"Modified attraction {attraction.get('attraction_id', 'unknown')} city: {original_city} → {destination}")
        else:
            logger.info(f"✅ Found {len(attractions)} attractions directly for {destination}")
            # Log some sample attraction details
            for i, attraction in enumerate(attractions[:3], 1):
                attraction_name = attraction.get('name', 'Unknown')
                attraction_id = attraction.get('attraction_id', 'Unknown')
                base_price = attraction.get('price', 0)
                logger.debug(f"  {i}. {attraction_name} (ID: {attraction_id}) - Base price: ${base_price}")
        
        # Apply category filtering if specified
        if category and category.lower() != 'all':
            logger.info(f"Filtering attractions by category: {category}")
            original_count = len(attractions)
            attractions = [a for a in attractions if a.get('category', '').lower() == category.lower()]
            logger.info(f"Category filter: {original_count} → {len(attractions)} attractions")
        
        # Apply budget filtering and sorting
        logger.info(f"Applying budget filtering for range: {budget_range}")
        budget_multipliers = {
            'low': 0.5,
            'medium': 1.0,
            'high': 1.8,
            'luxury': 3.0
        }
        
        multiplier = budget_multipliers.get(budget_range.lower(), 1.0)
        logger.info(f"Budget multiplier: {multiplier}")
        
        # Filter and enhance attractions based on search criteria
        logger.info(f"Processing up to 10 attractions from {len(attractions)} available")
        processed_attractions = []
        skipped_attractions = 0
        
        for i, attraction in enumerate(attractions[:10]):  # Limit to 10 results
            attraction_id = attraction.get('attraction_id', f'unknown_{i}')
            attraction_name = attraction.get('name', 'Unknown Attraction')
            logger.debug(f"Processing attraction {i+1}: {attraction_name} (ID: {attraction_id})")
            
            # Convert Decimal to int/float for JSON serialization
            original_price = float(attraction.get('price', 25))
            adjusted_price = int(original_price * multiplier)
            
            logger.debug(f"  Price calculation: ${original_price} × {multiplier} = ${adjusted_price}")
            
            processed_attraction = {
                'attraction_id': attraction_id,
                'name': attraction_name,
                'city': destination,
                'category': attraction.get('category', 'general'),
                'subcategory': attraction.get('subcategory', ''),
                'description': attraction.get('description', f"Explore {attraction_name} in {destination}"),
                'price': adjusted_price,
                'currency': attraction.get('currency', 'USD'),
                'duration': get_attraction_duration(duration, attraction.get('category', 'general')),
                'rating': float(attraction.get('rating', 4.0)),
                'reviews_count': attraction.get('reviews_count', 150 + i * 25),
                'address': attraction.get('address', f"Main Street, {destination}"),
                'coordinates': {
                    'latitude': attraction.get('latitude', 40.7128),
                    'longitude': attraction.get('longitude', -74.0060)
                },
                'opening_hours': get_opening_hours(attraction.get('category', 'general')),
                'website': f"https://example-attractions.com/{attraction_id}",
                'phone': attraction.get('phone', '+1-555-0123'),
                'accessibility': {
                    'wheelchair_accessible': attraction.get('wheelchair_accessible', True),
                    'audio_guide': attraction.get('audio_guide', False),
                    'sign_language': attraction.get('sign_language', False)
                },
                'amenities': get_attraction_amenities(attraction.get('category', 'general')),
                'booking_required': attraction.get('booking_required', False),
                'age_restrictions': attraction.get('age_restrictions', 'All ages'),
                'languages': attraction.get('languages', ['English']),
                'best_time_to_visit': get_best_time_to_visit(attraction.get('category', 'general')),
                'nearby_attractions': [],
                'transportation': {
                    'public_transport': True,
                    'parking_available': attraction.get('parking_available', True),
                    'walking_distance_from_center': f"{(i % 5) + 1} km"
                },
                'seasonal_info': get_seasonal_info(date, attraction.get('category', 'general')),
                'tips': get_attraction_tips(attraction.get('category', 'general'))
            }
            
            processed_attractions.append(processed_attraction)
            logger.debug(f"  ✅ Processed {attraction_name} - ${adjusted_price}, {processed_attraction['rating']}⭐")
        
        # Log processing summary
        logger.info(f"📊 Processing Summary:")
        logger.info(f"  - Attractions processed: {len(attractions[:10])}")
        logger.info(f"  - Attractions included: {len(processed_attractions)}")
        
        # Sort by rating (highest first)
        logger.info(f"Sorting {len(processed_attractions)} attractions by rating...")
        processed_attractions.sort(key=lambda x: x['rating'], reverse=True)
        
        if processed_attractions:
            highest_rated = processed_attractions[0]
            lowest_rated = processed_attractions[-1]
            rating_range = f"{lowest_rated['rating']:.1f} - {highest_rated['rating']:.1f}"
            logger.info(f"✅ Rating range after sorting: {rating_range}")
            logger.info(f"  Highest rated: {highest_rated['name']} - {highest_rated['rating']}⭐")
            logger.info(f"  Lowest rated: {lowest_rated['name']} - {lowest_rated['rating']}⭐")
        
        # Final summary logging
        logger.info(f"=== DYNAMODB SEARCH COMPLETE ===")
        logger.info(f"🎯 Search Results Summary:")
        logger.info(f"  - Destination: {destination}")
        logger.info(f"  - Date: {date}")
        logger.info(f"  - Category: {category}")
        logger.info(f"  - Budget range: {budget_range} (multiplier: {multiplier})")
        logger.info(f"  - Attractions found: {len(processed_attractions)}")
        
        if processed_attractions:
            avg_price = sum(a['price'] for a in processed_attractions) / len(processed_attractions)
            avg_rating = sum(a['rating'] for a in processed_attractions) / len(processed_attractions)
            logger.info(f"  - Average price: ${avg_price:.2f}")
            logger.info(f"  - Average rating: {avg_rating:.1f}⭐")
            
            # Log top 3 attractions
            logger.info(f"  - Top 3 attractions by rating:")
            for i, attraction in enumerate(processed_attractions[:3], 1):
                logger.info(f"    {i}. {attraction['name']} - ${attraction['price']} ({attraction['rating']}⭐)")
        
        logger.info(f"Returning {len(processed_attractions)} processed attractions")
        return processed_attractions
        
    except Exception as e:
        logger.error(f"❌ Error querying DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB error traceback:")
        logger.error(f"=== DYNAMODB SEARCH FAILED ===")
        # Return empty list if DynamoDB query fails
        return []

def get_attraction_duration(requested_duration: str, category: str) -> str:
    """Get appropriate duration based on request and category"""
    logger.debug(f"Determining duration for category: {category}, requested: {requested_duration}")
    
    category_durations = {
        'museums': '2-3 hours',
        'parks': '3-4 hours',
        'monuments': '1-2 hours',
        'tours': '4-6 hours',
        'entertainment': '2-4 hours',
        'shopping': '2-5 hours',
        'restaurants': '1-2 hours'
    }
    
    if requested_duration == 'half_day':
        duration = category_durations.get(category, '2-3 hours')
    elif requested_duration == 'full_day':
        duration = '6-8 hours'
    elif requested_duration == 'multi_day':
        duration = '2-3 days'
    else:
        duration = category_durations.get(category, '2-3 hours')
    
    logger.debug(f"Selected duration: {duration}")
    return duration

def get_opening_hours(category: str) -> Dict[str, str]:
    """Get typical opening hours based on category"""
    hours_by_category = {
        'museums': {'weekdays': '9:00 AM - 6:00 PM', 'weekends': '10:00 AM - 7:00 PM'},
        'parks': {'weekdays': '6:00 AM - 10:00 PM', 'weekends': '6:00 AM - 10:00 PM'},
        'monuments': {'weekdays': '8:00 AM - 8:00 PM', 'weekends': '8:00 AM - 8:00 PM'},
        'tours': {'weekdays': '9:00 AM - 5:00 PM', 'weekends': '9:00 AM - 6:00 PM'},
        'entertainment': {'weekdays': '10:00 AM - 11:00 PM', 'weekends': '10:00 AM - 12:00 AM'},
        'shopping': {'weekdays': '10:00 AM - 9:00 PM', 'weekends': '10:00 AM - 10:00 PM'}
    }
    
    return hours_by_category.get(category, {'weekdays': '9:00 AM - 6:00 PM', 'weekends': '10:00 AM - 7:00 PM'})

def get_attraction_amenities(category: str) -> List[str]:
    """Get amenities based on attraction category"""
    amenities_by_category = {
        'museums': ['Audio Guide', 'Gift Shop', 'Cafe', 'Restrooms', 'Coat Check'],
        'parks': ['Restrooms', 'Picnic Areas', 'Walking Trails', 'Playground', 'Parking'],
        'monuments': ['Information Center', 'Restrooms', 'Photography Allowed', 'Guided Tours'],
        'tours': ['Professional Guide', 'Transportation', 'Small Groups', 'Multiple Languages'],
        'entertainment': ['Concessions', 'Restrooms', 'Air Conditioning', 'Reserved Seating'],
        'shopping': ['Restrooms', 'Food Court', 'ATM', 'Customer Service', 'Parking']
    }
    
    return amenities_by_category.get(category, ['Restrooms', 'Information Desk', 'Accessibility Features'])

def get_best_time_to_visit(category: str) -> str:
    """Get best time to visit based on category"""
    best_times = {
        'museums': 'Weekday mornings (less crowded)',
        'parks': 'Early morning or late afternoon',
        'monuments': 'Early morning or sunset for best lighting',
        'tours': 'Morning tours for better weather',
        'entertainment': 'Evening shows are most popular',
        'shopping': 'Weekdays for less crowds, weekends for events'
    }
    
    return best_times.get(category, 'Morning or afternoon')

def get_seasonal_info(date: str, category: str) -> Dict[str, str]:
    """Get seasonal information based on date and category"""
    try:
        visit_date = datetime.strptime(date, '%Y-%m-%d')
        month = visit_date.month
        
        # Determine season
        if month in [12, 1, 2]:
            season = 'winter'
        elif month in [3, 4, 5]:
            season = 'spring'
        elif month in [6, 7, 8]:
            season = 'summer'
        else:
            season = 'fall'
        
        seasonal_info = {
            'winter': {
                'weather': 'Cold weather, dress warmly',
                'crowds': 'Lower crowds, shorter lines',
                'special': 'Holiday decorations and events'
            },
            'spring': {
                'weather': 'Mild weather, perfect for outdoor activities',
                'crowds': 'Moderate crowds',
                'special': 'Blooming flowers in parks and gardens'
            },
            'summer': {
                'weather': 'Warm weather, stay hydrated',
                'crowds': 'Peak season, expect crowds',
                'special': 'Extended hours, outdoor events'
            },
            'fall': {
                'weather': 'Cool weather, comfortable for walking',
                'crowds': 'Moderate crowds',
                'special': 'Beautiful autumn colors'
            }
        }
        
        return seasonal_info.get(season, seasonal_info['spring'])
        
    except ValueError:
        return {'weather': 'Check local weather', 'crowds': 'Varies by season', 'special': 'Seasonal events available'}

def get_attraction_tips(category: str) -> List[str]:
    """Get helpful tips based on attraction category"""
    tips_by_category = {
        'museums': [
            'Book tickets online to skip lines',
            'Visit on weekday mornings for smaller crowds',
            'Check for free admission days',
            'Download the museum app for self-guided tours'
        ],
        'parks': [
            'Wear comfortable walking shoes',
            'Bring water and snacks',
            'Check weather conditions before visiting',
            'Visit early morning for best wildlife viewing'
        ],
        'monuments': [
            'Bring a camera for photos',
            'Learn about the history beforehand',
            'Visit during golden hour for best photos',
            'Respect any photography restrictions'
        ],
        'tours': [
            'Arrive 15 minutes early',
            'Wear comfortable shoes',
            'Bring a small bag for essentials',
            'Ask questions - guides love engaged visitors'
        ],
        'entertainment': [
            'Check dress code requirements',
            'Arrive early for best seats',
            'Turn off mobile devices',
            'Check bag policy before arriving'
        ],
        'shopping': [
            'Compare prices between stores',
            'Ask about tax-free shopping for tourists',
            'Keep receipts for returns',
            'Check store hours before visiting'
        ]
    }
    
    return tips_by_category.get(category, [
        'Plan your visit in advance',
        'Check opening hours and admission fees',
        'Bring comfortable shoes',
        'Stay hydrated and take breaks'
    ])