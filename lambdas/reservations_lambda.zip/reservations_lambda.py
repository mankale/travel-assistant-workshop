import json
import boto3
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from decimal import Decimal

def decimal_default(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Configure comprehensive logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# Create formatter for detailed logs
formatter = logging.Formatter('[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s')
# Ensure handler exists
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def lambda_handler(event, context):
    """
    MCP-compatible Lambda function for reservation operations
    
    Expected input formats:
    
    CREATE RESERVATION:
    {
        "body": "{\"operation\": \"create\", \"user_email\": \"user@example.com\", \"destination\": \"Paris, France\", \"travel_dates\": {\"start_date\": \"2025-06-15\", \"end_date\": \"2025-06-22\"}, \"party_details\": {\"adults\": 2, \"children\": 1}}"
    }
    
    GET RESERVATION:
    {
        "body": "{\"operation\": \"get\", \"reservation_id\": \"RES123456\"}"
    }
    """
    
    # Log the incoming event for debugging
    logger.info("=== RESERVATION LAMBDA INVOCATION START ===")
    logger.info(f"Raw event received: {json.dumps(event, default=str)}")
    logger.info(f"Context: {context}")
    
    try:
        # Parse the incoming event with detailed logging
        logger.info("Parsing incoming event...")
        
        # Handle different event formats - API Gateway vs Direct Lambda invocation
        body = {}
        
        # Check if this is a direct Lambda invocation (parameters directly in event)
        if 'operation' in event:
            logger.info("Direct Lambda invocation detected - using event as body")
            body = event
            logger.info(f"Direct invocation body: {body}")
        
        # Check if this is API Gateway format (body field)
        elif event.get('body') is not None:
            if isinstance(event.get('body'), str):
                logger.info(f"API Gateway format - Event body is string: {event['body']}")
                if event['body'].strip():  # Check if not empty string
                    body = json.loads(event['body'])
                    logger.info(f"Parsed API Gateway body: {body}")
                else:
                    logger.warning("Event body is empty string")
                    body = {}
            elif isinstance(event.get('body'), dict):
                logger.info("API Gateway format - Event body is already a dict")
                body = event['body']
            else:
                logger.warning(f"Event body is unexpected type: {type(event.get('body'))}")
                body = event.get('body', {}) if event.get('body') is not None else {}
        
        # No body found in either format
        else:
            logger.warning("No request body found in either direct or API Gateway format")
            body = {}
        
        # Extract operation type
        operation = body.get('operation', '').lower()
        logger.info(f"Operation requested: '{operation}'")
        
        # Route to appropriate handler
        if operation == 'create':
            logger.info("Routing to create_reservation handler")
            return handle_create_reservation(body)
        elif operation == 'get':
            logger.info("Routing to get_reservation handler")
            return handle_get_reservation(body)
        else:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Invalid operation',
                    'supported_operations': ['create', 'get'],
                    'received_operation': operation,
                    'received_body': body
                }, default=decimal_default)
            }
            logger.error(f"Invalid operation: {operation}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
    except json.JSONDecodeError as e:
        error_response = {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body',
                'details': str(e),
                'received_body': event.get('body', 'No body')
            }, default=decimal_default)
        }
        logger.error(f"❌ JSON decode error: {str(e)}")
        logger.error(f"Raw body that failed to parse: {event.get('body', 'No body')}")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== RESERVATION LAMBDA INVOCATION FAILED (JSON) ===")
        return error_response
    
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full exception traceback:")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== RESERVATION LAMBDA INVOCATION FAILED (EXCEPTION) ===")
        return error_response

def handle_create_reservation(body: Dict) -> Dict:
    """
    Handle reservation creation
    """
    logger.info("=== CREATE RESERVATION START ===")
    
    try:
        # Extract required parameters
        user_email = body.get('user_email', '')
        destination = body.get('destination', '')
        travel_dates = body.get('travel_dates', {})
        party_details = body.get('party_details', {})
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - user_email: '{user_email}'")
        logger.info(f"  - destination: '{destination}'")
        logger.info(f"  - travel_dates: {travel_dates}")
        logger.info(f"  - party_details: {party_details}")
        
        # Validate required parameters
        logger.info("Validating required parameters...")
        missing_params = []
        if not user_email:
            missing_params.append('user_email')
        if not destination:
            missing_params.append('destination')
        if not travel_dates.get('start_date'):
            missing_params.append('travel_dates.start_date')
            
        if missing_params:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameters for reservation creation',
                    'missing': missing_params,
                    'required': ['user_email', 'destination', 'travel_dates.start_date'],
                    'received': body
                }, default=decimal_default)
            }
            logger.error(f"Validation failed - missing parameters: {missing_params}")
            return error_response
            
        logger.info("✅ All required parameters validated successfully")
        
        # Create reservation in DynamoDB
        reservation = create_reservation_in_dynamodb(body)
        
        if reservation:
            response_body = {
                'success': True,
                'message': 'Reservation created successfully',
                'reservation_id': reservation['reservation_id'],
                'confirmation_number': reservation['confirmation_number'],
                'reservation_details': {
                    'destination': reservation['destination'],
                    'travel_dates': reservation['travel_dates'],
                    'party_details': reservation['party_details'],
                    'total_cost': float(reservation['costs']['total']),
                    'currency': reservation['costs']['currency'],
                    'status': reservation['status']
                }
            }
            
            response = {
                'statusCode': 201,
                'body': json.dumps(response_body, default=decimal_default)
            }
            
            logger.info(f"✅ Reservation created successfully: {reservation['reservation_id']}")
            logger.info("=== CREATE RESERVATION SUCCESS ===")
            return response
        else:
            error_response = {
                'statusCode': 500,
                'body': json.dumps({
                    'error': 'Failed to create reservation',
                    'message': 'Database operation failed'
                }, default=decimal_default)
            }
            logger.error("❌ Failed to create reservation in database")
            return error_response
            
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Error creating reservation',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Error in create_reservation: {str(e)}")
        logger.exception("Full create_reservation error traceback:")
        logger.error("=== CREATE RESERVATION FAILED ===")
        return error_response

def handle_get_reservation(body: Dict) -> Dict:
    """
    Handle reservation retrieval
    """
    logger.info("=== GET RESERVATION START ===")
    
    try:
        # Extract reservation ID
        reservation_id = body.get('reservation_id', '')
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - reservation_id: '{reservation_id}'")
        
        # Validate required parameters
        if not reservation_id:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameter: reservation_id',
                    'received': body
                }, default=decimal_default)
            }
            logger.error("Validation failed - missing reservation_id")
            return error_response
            
        logger.info("✅ Reservation ID validated successfully")
        
        # Get reservation from DynamoDB
        reservation = get_reservation_from_dynamodb(reservation_id)
        
        if reservation:
            response_body = {
                'success': True,
                'reservation_found': True,
                'reservation': reservation
            }
            
            response = {
                'statusCode': 200,
                'body': json.dumps(response_body, default=decimal_default)
            }
            
            logger.info(f"✅ Reservation retrieved successfully: {reservation_id}")
            logger.info("=== GET RESERVATION SUCCESS ===")
            return response
        else:
            response_body = {
                'success': True,
                'reservation_found': False,
                'message': f'No reservation found with ID: {reservation_id}'
            }
            
            response = {
                'statusCode': 404,
                'body': json.dumps(response_body, default=decimal_default)
            }
            
            logger.warning(f"Reservation not found: {reservation_id}")
            logger.info("=== GET RESERVATION NOT FOUND ===")
            return response
            
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Error retrieving reservation',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Error in get_reservation: {str(e)}")
        logger.exception("Full get_reservation error traceback:")
        logger.error("=== GET RESERVATION FAILED ===")
        return error_response

def create_reservation_in_dynamodb(data: Dict) -> Optional[Dict]:
    """
    Create a new reservation in DynamoDB
    """
    logger.info("=== DYNAMODB CREATE START ===")
    
    try:
        # Initialize DynamoDB resource
        logger.info("Initializing DynamoDB resource...")
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('exec-travel-reservations')
        logger.info("✅ DynamoDB resource initialized successfully")
        
        # Generate unique reservation ID
        reservation_id = f"RES{str(uuid.uuid4())[:8].upper()}"
        confirmation_number = f"CONF{str(uuid.uuid4())[:6].upper()}"
        
        logger.info(f"Generated reservation_id: {reservation_id}")
        logger.info(f"Generated confirmation_number: {confirmation_number}")
        
        # Extract and process travel dates
        travel_dates = data.get('travel_dates', {})
        start_date = travel_dates.get('start_date')
        end_date = travel_dates.get('end_date')
        
        # Calculate duration if end_date provided, otherwise default to 7 days
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            if end_date:
                end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
                duration_days = (end_dt - start_dt).days
            else:
                duration_days = data.get('duration_days', 7)
                end_dt = start_dt + timedelta(days=duration_days)
                end_date = end_dt.isoformat()
        else:
            # Default dates if not provided
            start_dt = datetime.now() + timedelta(days=30)
            duration_days = 7
            end_dt = start_dt + timedelta(days=duration_days)
            start_date = start_dt.isoformat()
            end_date = end_dt.isoformat()
        
        # Extract party details
        party_details = data.get('party_details', {})
        adults = party_details.get('adults', 1)
        children = party_details.get('children', 0)
        total_travelers = adults + children
        
        # Build reservation object
        reservation = {
            'reservation_id': reservation_id,
            'user_email': data.get('user_email'),
            'status': 'pending',
            'created_date': datetime.now().isoformat(),
            'last_modified': datetime.now().isoformat(),
            
            'destination': data.get('destination'),
            'travel_dates': {
                'start_date': start_date,
                'end_date': end_date,
                'duration_days': duration_days
            },
            
            'party_details': {
                'adults': adults,
                'children': children,
                'total_travelers': total_travelers
            },
            
            'flight_details': data.get('flight_details', {
                'included': True,
                'airline': 'TBD',
                'flight_class': 'economy',
                'cost': Decimal('800')
            }),
            
            'accommodation': {
                'hotel_name': f"Hotel in {data.get('destination', 'Destination')}",
                'room_type': 'standard' if total_travelers <= 2 else 'family_room',
                'nights': duration_days,
                'cost_per_night': Decimal('150'),
                'total_cost': Decimal('150') * duration_days
            },
            
            'activities': data.get('activities', {
                'included': False,
                'estimated_count': 0,
                'estimated_cost': Decimal('0')
            }),
            
            'preferences': data.get('preferences', {
                'dietary_restrictions': [],
                'budget_level': 'mid_range',
                'loyalty_programs': []
            }),
            
            'contact_info': data.get('contact_info', {
                'primary_phone': '',
                'emergency_contact': {
                    'name': '',
                    'phone': '',
                    'relationship': ''
                }
            }),
            
            'special_requests': data.get('special_requests'),
            'booking_source': 'api',
            'confirmation_number': confirmation_number
        }
        
        # Calculate costs
        flight_cost = reservation['flight_details'].get('cost', Decimal('0'))
        hotel_cost = reservation['accommodation'].get('total_cost', Decimal('0'))
        activity_cost = reservation['activities'].get('estimated_cost', Decimal('0'))
        
        subtotal = flight_cost + hotel_cost + activity_cost
        taxes_fees = subtotal * Decimal('0.12')  # 12% taxes and fees
        total_cost = subtotal + taxes_fees
        
        reservation['costs'] = {
            'subtotal': subtotal,
            'taxes_fees': taxes_fees,
            'total': total_cost,
            'currency': 'USD'
        }
        
        logger.info(f"Reservation object created:")
        logger.info(f"  - Total cost: ${total_cost}")
        logger.info(f"  - Duration: {duration_days} days")
        logger.info(f"  - Travelers: {total_travelers}")
        
        # Save to DynamoDB
        logger.info("Saving reservation to DynamoDB...")
        table.put_item(Item=reservation)
        logger.info("✅ Reservation saved successfully")
        
        logger.info("=== DYNAMODB CREATE SUCCESS ===")
        return reservation
        
    except Exception as e:
        logger.error(f"❌ Error creating reservation in DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB create error traceback:")
        logger.error("=== DYNAMODB CREATE FAILED ===")
        return None

def get_reservation_from_dynamodb(reservation_id: str) -> Optional[Dict]:
    """
    Retrieve a reservation from DynamoDB by ID
    """
    logger.info("=== DYNAMODB GET START ===")
    logger.info(f"Searching for reservation_id: {reservation_id}")
    
    try:
        # Initialize DynamoDB resource
        logger.info("Initializing DynamoDB resource...")
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('exec-travel-reservations')
        logger.info("✅ DynamoDB resource initialized successfully")
        
        # Get item by primary key
        logger.info(f"Querying table for reservation_id: {reservation_id}")
        response = table.get_item(
            Key={'reservation_id': reservation_id}
        )
        
        logger.info(f"DynamoDB get_item response keys: {list(response.keys())}")
        
        if 'Item' in response:
            reservation = response['Item']
            logger.info(f"✅ Reservation found:")
            logger.info(f"  - Email: {reservation.get('user_email', 'N/A')}")
            logger.info(f"  - Destination: {reservation.get('destination', 'N/A')}")
            logger.info(f"  - Status: {reservation.get('status', 'N/A')}")
            logger.info(f"  - Total cost: ${reservation.get('costs', {}).get('total', 'N/A')}")
            
            logger.info("=== DYNAMODB GET SUCCESS ===")
            return reservation
        else:
            logger.warning(f"No reservation found with ID: {reservation_id}")
            logger.info("=== DYNAMODB GET NOT FOUND ===")
            return None
            
    except Exception as e:
        logger.error(f"❌ Error retrieving reservation from DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB get error traceback:")
        logger.error("=== DYNAMODB GET FAILED ===")
        return None