import json
import boto3
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from decimal import Decimal
import uuid

def decimal_default(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Configure comprehensive logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# Create formatter for detailed logs
formatter = logging.Formatter('[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s')
# Ensure handler exists
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def lambda_handler(event, context):
    """
    MCP-compatible Lambda function for loyalty program management
    
    Expected input format:
    {
        "body": "{\"action\": \"get_status\", \"user_id\": \"user123\", \"program\": \"airline\"}"
    }
    
    Supported actions:
    - get_status: Get loyalty program status and points
    - earn_points: Add points to account
    - redeem_points: Redeem points for rewards
    - get_rewards: List available rewards
    - get_history: Get transaction history
    """
    
    # Log the incoming event for debugging
    logger.info("=== LAMBDA INVOCATION START ===")
    logger.info(f"Raw event received: {json.dumps(event, default=str)}")
    logger.info(f"Context: {context}")
    logger.info(f"Function name: {context.function_name if context else 'Unknown'}")
    logger.info(f"Request ID: {context.aws_request_id if context else 'Unknown'}")
    logger.info(f"Remaining time: {context.get_remaining_time_in_millis() if context else 'Unknown'}ms")
    
    try:
        # Parse the incoming event with detailed logging
        logger.info("Step 1: Parsing incoming event...")
        
        # Handle different event formats - API Gateway vs Direct Lambda invocation
        body = {}
        
        # Check if this is a direct Lambda invocation (parameters directly in event)
        if 'action' in event and 'user_id' in event:
            logger.info("Direct Lambda invocation detected - using event as body")
            body = event
            logger.info(f"Direct invocation body: {body}")
        
        # Check if this is API Gateway format (body field)
        elif event.get('body') is not None:
            if isinstance(event.get('body'), str):
                logger.info(f"API Gateway format - Event body is string: {event['body']}")
                if event['body'].strip():  # Check if not empty string
                    body = json.loads(event['body'])
                    logger.info(f"Parsed API Gateway body: {body}")
                else:
                    logger.warning("Event body is empty string")
                    body = {}
            elif isinstance(event.get('body'), dict):
                logger.info("API Gateway format - Event body is already a dict")
                body = event['body']
            else:
                logger.warning(f"Event body is unexpected type: {type(event.get('body'))}")
                body = event.get('body', {}) if event.get('body') is not None else {}
        
        # No body found in either format
        else:
            logger.warning("No request body found in either direct or API Gateway format")
            body = {}
        
        # Extract loyalty program parameters with detailed logging
        logger.info("Step 2: Extracting request parameters...")
        
        action = body.get('action', '')
        user_id = body.get('user_id', '')
        program = body.get('program', 'general')  # airline, hotel, restaurant, general
        points = body.get('points', 0)
        reward_id = body.get('reward_id', '')
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - action: '{action}'")
        logger.info(f"  - user_id: '{user_id}'")
        logger.info(f"  - program: '{program}'")
        logger.info(f"  - points: {points}")
        logger.info(f"  - reward_id: '{reward_id}'")
        
        logger.info(f"Loyalty program request: {action} for user {user_id} in {program} program")
        
        # Validate required parameters with detailed logging
        logger.info("Step 3: Validating required parameters...")
        
        missing_params = []
        if not action:
            missing_params.append('action')
        if not user_id:
            missing_params.append('user_id')
            
        if missing_params:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameters',
                    'missing': missing_params,
                    'required': ['action', 'user_id'],
                    'received': body
                }, default=decimal_default)
            }
            logger.error(f"Validation failed - missing parameters: {missing_params}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
        logger.info("✅ All required parameters validated successfully")
        
        # Validate action
        logger.info("Step 4: Validating action...")
        
        valid_actions = ['get_status', 'earn_points', 'redeem_points', 'get_rewards', 'get_history']
        if action not in valid_actions:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Invalid action',
                    'action': action,
                    'valid_actions': valid_actions
                }, default=decimal_default)
            }
            logger.error(f"Invalid action: {action}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
        logger.info(f"✅ Action '{action}' is valid")
        
        # Process the loyalty program request
        logger.info(f"Step 5: Processing {action} request...")
        result = process_loyalty_request(action, user_id, program, points, reward_id)
        logger.info(f"Loyalty program request completed - action: {action}")
        
        # Return MCP-compatible response
        response_body = {
            'action': action,
            'user_id': user_id,
            'program': program,
            'result': result,
            'timestamp': datetime.now().isoformat()
        }
        
        response = {
            'statusCode': 200,
            'body': json.dumps(response_body, default=decimal_default)
        }
        
        logger.info(f"✅ Loyalty program request completed successfully: {action}")
        logger.info(f"Response body size: {len(json.dumps(response_body, default=decimal_default))} characters")
        logger.info("=== LAMBDA INVOCATION SUCCESS ===")
        return response
        
    except json.JSONDecodeError as e:
        error_response = {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body',
                'details': str(e),
                'received_body': event.get('body', 'No body')
            }, default=decimal_default)
        }
        logger.error(f"❌ JSON decode error: {str(e)}")
        logger.error(f"Raw body that failed to parse: {event.get('body', 'No body')}")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (JSON) ===")
        return error_response
    
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full exception traceback:")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (EXCEPTION) ===")
        return error_response

def process_loyalty_request(action: str, user_id: str, program: str, points: int, reward_id: str) -> Dict[str, Any]:
    """
    Process loyalty program requests using DynamoDB
    """
    logger.info(f"=== LOYALTY PROCESSING START ===")
    logger.info(f"Processing: {action} for user {user_id} in {program} program")
    
    # Initialize DynamoDB resource
    logger.info("Initializing DynamoDB resource...")
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('synthetic-loyalty')
        logger.info("✅ DynamoDB resource initialized successfully")
        logger.info(f"Table name: {table.table_name}")
        
        # Validate table exists and is accessible
        logger.debug("Validating table accessibility...")
        table_status = table.table_status
        logger.info(f"Table status: {table_status}")
        
        if table_status != 'ACTIVE':
            logger.warning(f"⚠️ Table status is {table_status}, not ACTIVE")
        
    except Exception as e:
        logger.error(f"❌ Failed to initialize DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB initialization error:")
        raise e
    
    try:
        if action == 'get_status':
            return get_loyalty_status(table, user_id, program)
        elif action == 'earn_points':
            return earn_loyalty_points(table, user_id, program, points)
        elif action == 'redeem_points':
            return redeem_loyalty_points(table, user_id, program, reward_id, points)
        elif action == 'get_rewards':
            return get_available_rewards(table, user_id, program)
        elif action == 'get_history':
            return get_loyalty_history(table, user_id, program)
        else:
            raise ValueError(f"Unsupported action: {action}")
            
    except Exception as e:
        logger.error(f"❌ Error processing loyalty request: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full loyalty processing error:")
        logger.error(f"=== LOYALTY PROCESSING FAILED ===")
        raise e

def get_loyalty_status(table, user_id: str, program: str) -> Dict[str, Any]:
    """Get user's loyalty program status"""
    logger.info(f"Getting loyalty status for user {user_id} in {program} program")
    
    try:
        # Try to get existing user record
        response = table.get_item(
            Key={
                'user_id': user_id,
                'program': program
            }
        )
        
        if 'Item' in response:
            user_data = response['Item']
            logger.info(f"Found existing user record: {user_data.get('tier', 'Bronze')} tier, {user_data.get('points', 0)} points")
        else:
            # Create new user record
            logger.info(f"Creating new user record for {user_id}")
            user_data = create_new_loyalty_user(table, user_id, program)
        
        # Calculate tier and benefits
        current_points = int(user_data.get('points', 0))
        tier_info = calculate_tier(current_points, program)
        
        status = {
            'user_id': user_id,
            'program': program,
            'current_points': current_points,
            'tier': tier_info['tier'],
            'tier_benefits': tier_info['benefits'],
            'points_to_next_tier': tier_info['points_to_next'],
            'lifetime_points': int(user_data.get('lifetime_points', current_points)),
            'member_since': user_data.get('member_since', datetime.now().isoformat()),
            'last_activity': user_data.get('last_activity', datetime.now().isoformat()),
            'expiring_points': get_expiring_points(user_data),
            'recent_transactions': get_recent_transactions(user_data)
        }
        
        logger.info(f"✅ Status retrieved: {tier_info['tier']} tier, {current_points} points")
        return status
        
    except Exception as e:
        logger.error(f"❌ Error getting loyalty status: {str(e)}")
        raise e

def earn_loyalty_points(table, user_id: str, program: str, points: int) -> Dict[str, Any]:
    """Add points to user's loyalty account"""
    logger.info(f"Adding {points} points to user {user_id} in {program} program")
    
    if points <= 0:
        raise ValueError("Points must be positive")
    
    try:
        # Get current status
        current_status = get_loyalty_status(table, user_id, program)
        
        # Calculate new totals
        new_points = current_status['current_points'] + points
        new_lifetime = current_status['lifetime_points'] + points
        
        # Create transaction record
        transaction = {
            'transaction_id': str(uuid.uuid4()),
            'type': 'earn',
            'points': points,
            'description': f'Earned {points} points',
            'timestamp': datetime.now().isoformat()
        }
        
        # Update user record
        table.update_item(
            Key={
                'user_id': user_id,
                'program': program
            },
            UpdateExpression='SET points = :points, lifetime_points = :lifetime, last_activity = :activity, transactions = list_append(if_not_exists(transactions, :empty_list), :transaction)',
            ExpressionAttributeValues={
                ':points': new_points,
                ':lifetime': new_lifetime,
                ':activity': datetime.now().isoformat(),
                ':empty_list': [],
                ':transaction': [transaction]
            }
        )
        
        # Calculate new tier
        tier_info = calculate_tier(new_points, program)
        
        result = {
            'transaction_id': transaction['transaction_id'],
            'points_earned': points,
            'new_balance': new_points,
            'previous_balance': current_status['current_points'],
            'new_tier': tier_info['tier'],
            'previous_tier': current_status['tier'],
            'tier_upgraded': tier_info['tier'] != current_status['tier'],
            'lifetime_points': new_lifetime
        }
        
        logger.info(f"✅ Points earned successfully: {points} points, new balance: {new_points}")
        if result['tier_upgraded']:
            logger.info(f"🎉 Tier upgraded: {current_status['tier']} → {tier_info['tier']}")
        
        return result
        
    except Exception as e:
        logger.error(f"❌ Error earning points: {str(e)}")
        raise e

def redeem_loyalty_points(table, user_id: str, program: str, reward_id: str, points: int) -> Dict[str, Any]:
    """Redeem points for rewards"""
    logger.info(f"Redeeming {points} points for reward {reward_id} for user {user_id}")
    
    try:
        # Get current status
        current_status = get_loyalty_status(table, user_id, program)
        
        # Validate sufficient points
        if current_status['current_points'] < points:
            raise ValueError(f"Insufficient points. Available: {current_status['current_points']}, Required: {points}")
        
        # Get reward details
        reward = get_reward_details(reward_id, program)
        if not reward:
            raise ValueError(f"Invalid reward ID: {reward_id}")
        
        # Calculate new balance
        new_points = current_status['current_points'] - points
        
        # Create transaction record
        transaction = {
            'transaction_id': str(uuid.uuid4()),
            'type': 'redeem',
            'points': -points,
            'reward_id': reward_id,
            'reward_name': reward['name'],
            'description': f'Redeemed {points} points for {reward["name"]}',
            'timestamp': datetime.now().isoformat()
        }
        
        # Update user record
        table.update_item(
            Key={
                'user_id': user_id,
                'program': program
            },
            UpdateExpression='SET points = :points, last_activity = :activity, transactions = list_append(if_not_exists(transactions, :empty_list), :transaction)',
            ExpressionAttributeValues={
                ':points': new_points,
                ':activity': datetime.now().isoformat(),
                ':empty_list': [],
                ':transaction': [transaction]
            }
        )
        
        result = {
            'transaction_id': transaction['transaction_id'],
            'points_redeemed': points,
            'new_balance': new_points,
            'previous_balance': current_status['current_points'],
            'reward': reward,
            'redemption_code': generate_redemption_code(),
            'expiry_date': (datetime.now() + timedelta(days=365)).isoformat()
        }
        
        logger.info(f"✅ Points redeemed successfully: {points} points for {reward['name']}")
        return result
        
    except Exception as e:
        logger.error(f"❌ Error redeeming points: {str(e)}")
        raise e

def get_available_rewards(table, user_id: str, program: str) -> Dict[str, Any]:
    """Get available rewards for the program"""
    logger.info(f"Getting available rewards for {program} program")
    
    try:
        # Get user status to filter rewards by tier and points
        current_status = get_loyalty_status(table, user_id, program)
        
        # Get all rewards for the program
        all_rewards = get_program_rewards(program)
        
        # Filter rewards based on user's tier and points
        available_rewards = []
        tier_rewards = []
        
        for reward in all_rewards:
            if reward['points_required'] <= current_status['current_points']:
                if reward.get('tier_required', 'Bronze') in get_tier_hierarchy(current_status['tier']):
                    available_rewards.append(reward)
            
            if reward.get('tier_required') == current_status['tier']:
                tier_rewards.append(reward)
        
        result = {
            'user_tier': current_status['tier'],
            'current_points': current_status['current_points'],
            'available_rewards': available_rewards,
            'tier_exclusive_rewards': tier_rewards,
            'total_available': len(available_rewards),
            'program': program
        }
        
        logger.info(f"✅ Found {len(available_rewards)} available rewards for {current_status['tier']} tier")
        return result
        
    except Exception as e:
        logger.error(f"❌ Error getting rewards: {str(e)}")
        raise e

def get_loyalty_history(table, user_id: str, program: str) -> Dict[str, Any]:
    """Get user's loyalty transaction history"""
    logger.info(f"Getting loyalty history for user {user_id}")
    
    try:
        # Get user record
        response = table.get_item(
            Key={
                'user_id': user_id,
                'program': program
            }
        )
        
        if 'Item' not in response:
            logger.warning(f"No loyalty record found for user {user_id}")
            return {
                'user_id': user_id,
                'program': program,
                'transactions': [],
                'total_transactions': 0
            }
        
        user_data = response['Item']
        transactions = user_data.get('transactions', [])
        
        # Sort transactions by timestamp (newest first)
        sorted_transactions = sorted(transactions, key=lambda x: x['timestamp'], reverse=True)
        
        # Calculate summary statistics
        total_earned = sum(t['points'] for t in transactions if t['points'] > 0)
        total_redeemed = abs(sum(t['points'] for t in transactions if t['points'] < 0))
        
        result = {
            'user_id': user_id,
            'program': program,
            'transactions': sorted_transactions[:50],  # Last 50 transactions
            'total_transactions': len(transactions),
            'summary': {
                'total_earned': total_earned,
                'total_redeemed': total_redeemed,
                'net_points': total_earned - total_redeemed,
                'member_since': user_data.get('member_since'),
                'last_activity': user_data.get('last_activity')
            }
        }
        
        logger.info(f"✅ Retrieved {len(sorted_transactions)} transactions")
        return result
        
    except Exception as e:
        logger.error(f"❌ Error getting history: {str(e)}")
        raise e

def create_new_loyalty_user(table, user_id: str, program: str) -> Dict[str, Any]:
    """Create a new loyalty program user"""
    logger.info(f"Creating new loyalty user: {user_id} in {program}")
    
    user_data = {
        'user_id': user_id,
        'program': program,
        'points': 0,
        'lifetime_points': 0,
        'tier': 'Bronze',
        'member_since': datetime.now().isoformat(),
        'last_activity': datetime.now().isoformat(),
        'transactions': []
    }
    
    table.put_item(Item=user_data)
    logger.info(f"✅ New user created with Bronze tier")
    
    return user_data

def calculate_tier(points: int, program: str) -> Dict[str, Any]:
    """Calculate user tier based on points"""
    
    tier_thresholds = {
        'airline': {
            'Bronze': {'min': 0, 'max': 24999},
            'Silver': {'min': 25000, 'max': 49999},
            'Gold': {'min': 50000, 'max': 99999},
            'Platinum': {'min': 100000, 'max': float('inf')}
        },
        'hotel': {
            'Bronze': {'min': 0, 'max': 9999},
            'Silver': {'min': 10000, 'max': 24999},
            'Gold': {'min': 25000, 'max': 49999},
            'Platinum': {'min': 50000, 'max': float('inf')}
        },
        'general': {
            'Bronze': {'min': 0, 'max': 4999},
            'Silver': {'min': 5000, 'max': 14999},
            'Gold': {'min': 15000, 'max': 29999},
            'Platinum': {'min': 30000, 'max': float('inf')}
        }
    }
    
    thresholds = tier_thresholds.get(program, tier_thresholds['general'])
    
    for tier, range_info in thresholds.items():
        if range_info['min'] <= points <= range_info['max']:
            # Find next tier
            next_tier_points = None
            for next_tier, next_range in thresholds.items():
                if next_range['min'] > points:
                    next_tier_points = next_range['min'] - points
                    break
            
            return {
                'tier': tier,
                'benefits': get_tier_benefits(tier, program),
                'points_to_next': next_tier_points
            }
    
    return {
        'tier': 'Bronze',
        'benefits': get_tier_benefits('Bronze', program),
        'points_to_next': thresholds['Silver']['min']
    }

def get_tier_benefits(tier: str, program: str) -> List[str]:
    """Get benefits for a specific tier"""
    
    benefits = {
        'airline': {
            'Bronze': ['Priority check-in', 'Free seat selection'],
            'Silver': ['Priority boarding', 'Free checked bag', 'Lounge access'],
            'Gold': ['Premium seat upgrade', 'Priority baggage', 'Companion pass'],
            'Platinum': ['First class upgrade', 'Concierge service', 'Global lounge access']
        },
        'hotel': {
            'Bronze': ['Late checkout', 'WiFi included'],
            'Silver': ['Room upgrade', 'Welcome amenity', 'Flexible cancellation'],
            'Gold': ['Suite upgrade', 'Executive lounge', 'Free breakfast'],
            'Platinum': ['Presidential suite', 'Personal concierge', 'Spa credits']
        },
        'general': {
            'Bronze': ['Member discounts', 'Birthday bonus'],
            'Silver': ['Exclusive offers', 'Priority support', 'Double points days'],
            'Gold': ['VIP events', 'Personal advisor', 'Premium rewards'],
            'Platinum': ['Luxury experiences', 'Concierge service', 'Unlimited benefits']
        }
    }
    
    return benefits.get(program, benefits['general']).get(tier, [])

def get_tier_hierarchy(current_tier: str) -> List[str]:
    """Get tier hierarchy for reward filtering"""
    hierarchy = {
        'Bronze': ['Bronze'],
        'Silver': ['Bronze', 'Silver'],
        'Gold': ['Bronze', 'Silver', 'Gold'],
        'Platinum': ['Bronze', 'Silver', 'Gold', 'Platinum']
    }
    
    return hierarchy.get(current_tier, ['Bronze'])

def get_program_rewards(program: str) -> List[Dict[str, Any]]:
    """Get all rewards for a program"""
    
    rewards = {
        'airline': [
            {'id': 'flight_discount_10', 'name': '10% Flight Discount', 'points_required': 5000, 'tier_required': 'Bronze'},
            {'id': 'free_baggage', 'name': 'Free Checked Bag', 'points_required': 8000, 'tier_required': 'Silver'},
            {'id': 'lounge_pass', 'name': 'Airport Lounge Pass', 'points_required': 12000, 'tier_required': 'Silver'},
            {'id': 'upgrade_domestic', 'name': 'Domestic Flight Upgrade', 'points_required': 20000, 'tier_required': 'Gold'},
            {'id': 'free_flight_domestic', 'name': 'Free Domestic Flight', 'points_required': 35000, 'tier_required': 'Gold'},
            {'id': 'upgrade_international', 'name': 'International Flight Upgrade', 'points_required': 50000, 'tier_required': 'Platinum'},
            {'id': 'free_flight_international', 'name': 'Free International Flight', 'points_required': 80000, 'tier_required': 'Platinum'}
        ],
        'hotel': [
            {'id': 'room_upgrade', 'name': 'Room Upgrade', 'points_required': 3000, 'tier_required': 'Bronze'},
            {'id': 'late_checkout', 'name': 'Late Checkout', 'points_required': 2000, 'tier_required': 'Bronze'},
            {'id': 'free_breakfast', 'name': 'Complimentary Breakfast', 'points_required': 5000, 'tier_required': 'Silver'},
            {'id': 'spa_credit', 'name': '$50 Spa Credit', 'points_required': 8000, 'tier_required': 'Silver'},
            {'id': 'free_night', 'name': 'Free Night Stay', 'points_required': 15000, 'tier_required': 'Gold'},
            {'id': 'suite_upgrade', 'name': 'Suite Upgrade', 'points_required': 25000, 'tier_required': 'Gold'},
            {'id': 'luxury_package', 'name': 'Luxury Weekend Package', 'points_required': 40000, 'tier_required': 'Platinum'}
        ],
        'general': [
            {'id': 'gift_card_25', 'name': '$25 Gift Card', 'points_required': 2500, 'tier_required': 'Bronze'},
            {'id': 'gift_card_50', 'name': '$50 Gift Card', 'points_required': 5000, 'tier_required': 'Bronze'},
            {'id': 'gift_card_100', 'name': '$100 Gift Card', 'points_required': 10000, 'tier_required': 'Silver'},
            {'id': 'experience_voucher', 'name': 'Experience Voucher', 'points_required': 15000, 'tier_required': 'Gold'},
            {'id': 'luxury_item', 'name': 'Luxury Item', 'points_required': 25000, 'tier_required': 'Platinum'}
        ]
    }
    
    return rewards.get(program, rewards['general'])

def get_reward_details(reward_id: str, program: str) -> Optional[Dict[str, Any]]:
    """Get details for a specific reward"""
    rewards = get_program_rewards(program)
    
    for reward in rewards:
        if reward['id'] == reward_id:
            return reward
    
    return None

def generate_redemption_code() -> str:
    """Generate a unique redemption code"""
    return f"RDM{datetime.now().strftime('%Y%m%d')}{str(uuid.uuid4())[:8].upper()}"

def get_expiring_points(user_data: Dict[str, Any]) -> Dict[str, Any]:
    """Get information about expiring points"""
    # Simulate expiring points (in real implementation, this would be based on transaction dates)
    current_points = int(user_data.get('points', 0))
    expiring_soon = min(current_points // 10, 1000)  # 10% of points or 1000, whichever is smaller
    
    return {
        'points_expiring': expiring_soon,
        'expiry_date': (datetime.now() + timedelta(days=90)).isoformat(),
        'days_until_expiry': 90
    }

def get_recent_transactions(user_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Get recent transactions"""
    transactions = user_data.get('transactions', [])
    
    # Sort by timestamp and return last 5
    sorted_transactions = sorted(transactions, key=lambda x: x['timestamp'], reverse=True)
    return sorted_transactions[:5]