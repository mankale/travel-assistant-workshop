import json
import boto3
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from decimal import Decimal

def decimal_default(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Configure comprehensive logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# Create formatter for detailed logs
formatter = logging.Formatter('[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s')
# Ensure handler exists
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def lambda_handler(event, context):
    """
    MCP-compatible Lambda function for restaurant search
    
    Expected input format:
    {
        "body": "{\"destination\": \"Paris\", \"date\": \"2024-12-15\", \"cuisine\": \"french\", \"budget_range\": \"medium\", \"party_size\": 4}"
    }
    """
    
    # Log the incoming event for debugging
    logger.info("=== LAMBDA INVOCATION START ===")
    logger.info(f"Raw event received: {json.dumps(event, default=str)}")
    logger.info(f"Context: {context}")
    logger.info(f"Function name: {context.function_name if context else 'Unknown'}")
    logger.info(f"Request ID: {context.aws_request_id if context else 'Unknown'}")
    logger.info(f"Remaining time: {context.get_remaining_time_in_millis() if context else 'Unknown'}ms")
    
    try:
        # Parse the incoming event with detailed logging
        logger.info("Step 1: Parsing incoming event...")
        
        # Handle different event formats - API Gateway vs Direct Lambda invocation
        body = {}
        
        # Check if this is a direct Lambda invocation (parameters directly in event)
        if 'destination' in event and 'date' in event:
            logger.info("Direct Lambda invocation detected - using event as body")
            body = event
            logger.info(f"Direct invocation body: {body}")
        
        # Check if this is API Gateway format (body field)
        elif event.get('body') is not None:
            if isinstance(event.get('body'), str):
                logger.info(f"API Gateway format - Event body is string: {event['body']}")
                if event['body'].strip():  # Check if not empty string
                    body = json.loads(event['body'])
                    logger.info(f"Parsed API Gateway body: {body}")
                else:
                    logger.warning("Event body is empty string")
                    body = {}
            elif isinstance(event.get('body'), dict):
                logger.info("API Gateway format - Event body is already a dict")
                body = event['body']
            else:
                logger.warning(f"Event body is unexpected type: {type(event.get('body'))}")
                body = event.get('body', {}) if event.get('body') is not None else {}
        
        # No body found in either format
        else:
            logger.warning("No request body found in either direct or API Gateway format")
            body = {}
        
        # Extract restaurant search parameters with detailed logging
        logger.info("Step 2: Extracting search parameters...")
        
        destination = body.get('destination', '')
        date = body.get('date', '')
        time = body.get('time', '19:00')  # Default to 7 PM
        cuisine = body.get('cuisine', 'all')
        budget_range = body.get('budget_range', 'medium')
        party_size = body.get('party_size', 2)
        dietary_restrictions = body.get('dietary_restrictions', [])
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - destination: '{destination}'")
        logger.info(f"  - date: '{date}'")
        logger.info(f"  - time: '{time}'")
        logger.info(f"  - cuisine: '{cuisine}'")
        logger.info(f"  - budget_range: '{budget_range}'")
        logger.info(f"  - party_size: {party_size}")
        logger.info(f"  - dietary_restrictions: {dietary_restrictions}")
        
        logger.info(f"Restaurant search request: {destination}, {date} at {time}, {cuisine} cuisine, {budget_range} budget, party of {party_size}")
        
        # Validate required parameters with detailed logging
        logger.info("Step 3: Validating required parameters...")
        
        missing_params = []
        if not destination:
            missing_params.append('destination')
        if not date:
            missing_params.append('date')
            
        if missing_params:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameters',
                    'missing': missing_params,
                    'required': ['destination', 'date'],
                    'received': body
                }, default=decimal_default)
            }
            logger.error(f"Validation failed - missing parameters: {missing_params}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
        logger.info("✅ All required parameters validated successfully")
        
        # Validate date and time format
        logger.info("Step 4: Validating date and time format...")
        
        try:
            logger.info(f"Parsing date: {date}")
            reservation_date = datetime.strptime(date, '%Y-%m-%d')
            logger.info(f"Parsed date: {reservation_date}")
            
            logger.info(f"Parsing time: {time}")
            reservation_time = datetime.strptime(time, '%H:%M').time()
            logger.info(f"Parsed time: {reservation_time}")
            
            # Check if date is in the past
            today = datetime.now().date()
            if reservation_date.date() < today:
                logger.warning(f"Reservation date {date} is in the past")
            
        except ValueError as e:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Invalid date or time format. Use YYYY-MM-DD for date and HH:MM for time',
                    'details': str(e),
                    'received_date': date,
                    'received_time': time
                }, default=decimal_default)
            }
            logger.error(f"Invalid date/time format: {date}, {time}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
        
        # Search restaurants from DynamoDB synthetic data
        logger.info("Step 5: Starting restaurant search from DynamoDB...")
        restaurants = search_restaurants_from_dynamodb(destination, date, time, cuisine, budget_range, party_size, dietary_restrictions)
        logger.info(f"Restaurant search completed - found {len(restaurants)} restaurants")
        
        # Return MCP-compatible response
        response_body = {
            'restaurants': restaurants,
            'search_params': {
                'destination': destination,
                'date': date,
                'time': time,
                'cuisine': cuisine,
                'budget_range': budget_range,
                'party_size': party_size,
                'dietary_restrictions': dietary_restrictions
            },
            'total_results': len(restaurants)
        }
        
        response = {
            'statusCode': 200,
            'body': json.dumps(response_body, default=decimal_default)
        }
        
        logger.info(f"✅ Restaurant search completed successfully: {len(restaurants)} results found")
        logger.info(f"Response body size: {len(json.dumps(response_body, default=decimal_default))} characters")
        logger.info("=== LAMBDA INVOCATION SUCCESS ===")
        return response
        
    except json.JSONDecodeError as e:
        error_response = {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body',
                'details': str(e),
                'received_body': event.get('body', 'No body')
            }, default=decimal_default)
        }
        logger.error(f"❌ JSON decode error: {str(e)}")
        logger.error(f"Raw body that failed to parse: {event.get('body', 'No body')}")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (JSON) ===")
        return error_response
    
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full exception traceback:")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (EXCEPTION) ===")
        return error_response

def search_restaurants_from_dynamodb(destination: str, date: str, time: str, cuisine: str, budget_range: str, party_size: int, dietary_restrictions: List[str]) -> List[Dict]:
    """
    Search restaurants from DynamoDB synthetic data
    """
    logger.info(f"=== DYNAMODB SEARCH START ===")
    logger.info(f"Search parameters: destination={destination}, cuisine={cuisine}, budget={budget_range}, party_size={party_size}")
    
    # Initialize DynamoDB resource
    logger.info("Initializing DynamoDB resource...")
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('exec-synthetic-restaurants')
        logger.info("✅ DynamoDB resource initialized successfully")
        logger.info(f"Table name: {table.table_name}")
        
        # Validate table exists and is accessible
        logger.debug("Validating table accessibility...")
        table_status = table.table_status
        logger.info(f"Table status: {table_status}")
        
        if table_status != 'ACTIVE':
            logger.warning(f"⚠️ Table status is {table_status}, not ACTIVE")
        
    except Exception as e:
        logger.error(f"❌ Failed to initialize DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB initialization error:")
        raise e
    
    try:
        # Query using GSI for city
        logger.info(f"Querying DynamoDB for city: {destination}")
        logger.info("Using CityIndex GSI...")
        
        query_params = {
            'IndexName': 'CityIndex',
            'KeyConditionExpression': 'city = :city',
            'ExpressionAttributeValues': {
                ':city': destination
            }
        }
        logger.info(f"Query parameters: {query_params}")
        
        response = table.query(**query_params)
        logger.info(f"DynamoDB query response: Count={response.get('Count', 0)}, ScannedCount={response.get('ScannedCount', 0)}")
        
        restaurants = response.get('Items', [])
        logger.info(f"Found {len(restaurants)} restaurants for city: {destination}")
        
        # If no restaurants found for exact city, get sample restaurants and modify them
        if not restaurants:
            logger.warning(f"No restaurants found for {destination}, falling back to sample data")
            logger.info("Performing table scan for sample restaurants...")
            
            scan_response = table.scan(Limit=15)
            restaurants = scan_response.get('Items', [])
            logger.info(f"Scan returned {len(restaurants)} sample restaurants")
            
            # Modify sample restaurants to match the search criteria
            logger.info(f"Modifying sample restaurants to match destination: {destination}")
            for restaurant in restaurants:
                original_city = restaurant.get('city', 'Unknown')
                restaurant['city'] = destination
                logger.debug(f"Modified restaurant {restaurant.get('restaurant_id', 'unknown')} city: {original_city} → {destination}")
        else:
            logger.info(f"✅ Found {len(restaurants)} restaurants directly for {destination}")
            # Log some sample restaurant details
            for i, restaurant in enumerate(restaurants[:3], 1):
                restaurant_name = restaurant.get('name', 'Unknown')
                restaurant_id = restaurant.get('restaurant_id', 'Unknown')
                base_price = restaurant.get('average_price', 0)
                logger.debug(f"  {i}. {restaurant_name} (ID: {restaurant_id}) - Avg price: ${base_price}")
        
        # Apply cuisine filtering if specified
        if cuisine and cuisine.lower() != 'all':
            logger.info(f"Filtering restaurants by cuisine: {cuisine}")
            original_count = len(restaurants)
            restaurants = [r for r in restaurants if r.get('cuisine', '').lower() == cuisine.lower()]
            logger.info(f"Cuisine filter: {original_count} → {len(restaurants)} restaurants")
        
        # Apply budget filtering and sorting
        logger.info(f"Applying budget filtering for range: {budget_range}")
        budget_multipliers = {
            'low': 0.6,
            'medium': 1.0,
            'high': 1.8,
            'luxury': 3.0
        }
        
        multiplier = budget_multipliers.get(budget_range.lower(), 1.0)
        logger.info(f"Budget multiplier: {multiplier}")
        
        # Filter and enhance restaurants based on search criteria
        logger.info(f"Processing up to 10 restaurants from {len(restaurants)} available")
        processed_restaurants = []
        skipped_restaurants = 0
        
        for i, restaurant in enumerate(restaurants[:10]):  # Limit to 10 results
            restaurant_id = restaurant.get('restaurant_id', f'unknown_{i}')
            restaurant_name = restaurant.get('name', 'Unknown Restaurant')
            logger.debug(f"Processing restaurant {i+1}: {restaurant_name} (ID: {restaurant_id})")
            
            # Convert Decimal to int/float for JSON serialization
            original_price = float(restaurant.get('average_price', 50))
            adjusted_price = int(original_price * multiplier)
            
            logger.debug(f"  Price calculation: ${original_price} × {multiplier} = ${adjusted_price}")
            
            # Check if restaurant can accommodate party size
            max_party_size = restaurant.get('max_party_size', 8)
            if party_size > max_party_size:
                logger.debug(f"  ⚠️ Skipping {restaurant_name}: party_size ({party_size}) > max_party_size ({max_party_size})")
                skipped_restaurants += 1
                continue
            
            logger.debug(f"  ✅ Restaurant can accommodate party of {party_size} (max: {max_party_size})")
            
            processed_restaurant = {
                'restaurant_id': restaurant_id,
                'name': restaurant_name,
                'city': destination,
                'cuisine': restaurant.get('cuisine', 'International'),
                'subcuisine': restaurant.get('subcuisine', ''),
                'description': restaurant.get('description', f"Authentic {restaurant.get('cuisine', 'international')} cuisine in {destination}"),
                'average_price': adjusted_price,
                'price_range': get_price_range(adjusted_price),
                'currency': restaurant.get('currency', 'USD'),
                'rating': float(restaurant.get('rating', 4.0)),
                'reviews_count': restaurant.get('reviews_count', 200 + i * 50),
                'address': restaurant.get('address', f"Main Street, {destination}"),
                'phone': restaurant.get('phone', '+1-555-0123'),
                'website': f"https://example-restaurants.com/{restaurant_id}",
                'reservation_required': restaurant.get('reservation_required', True),
                'reservation_url': f"https://reservations.example.com/{restaurant_id}",
                'coordinates': {
                    'latitude': restaurant.get('latitude', 40.7128),
                    'longitude': restaurant.get('longitude', -74.0060)
                },
                'opening_hours': get_restaurant_hours(restaurant.get('cuisine', 'International')),
                'dress_code': get_dress_code(budget_range),
                'atmosphere': restaurant.get('atmosphere', 'Casual'),
                'seating_capacity': restaurant.get('seating_capacity', 50 + i * 20),
                'max_party_size': max_party_size,
                'dietary_options': get_dietary_options(restaurant.get('cuisine', 'International')),
                'amenities': get_restaurant_amenities(budget_range),
                'payment_methods': ['Credit Card', 'Debit Card', 'Cash'],
                'languages_spoken': restaurant.get('languages_spoken', ['English']),
                'parking': {
                    'available': restaurant.get('parking_available', True),
                    'type': 'Street parking' if budget_range == 'low' else 'Valet available',
                    'cost': 'Free' if budget_range in ['low', 'medium'] else '$10-20'
                },
                'accessibility': {
                    'wheelchair_accessible': restaurant.get('wheelchair_accessible', True),
                    'braille_menu': restaurant.get('braille_menu', False),
                    'hearing_assistance': restaurant.get('hearing_assistance', False)
                },
                'special_features': get_special_features(restaurant.get('cuisine', 'International'), budget_range),
                'popular_dishes': get_popular_dishes(restaurant.get('cuisine', 'International')),
                'wine_list': restaurant.get('wine_list', budget_range in ['high', 'luxury']),
                'private_dining': restaurant.get('private_dining', budget_range in ['high', 'luxury']),
                'outdoor_seating': restaurant.get('outdoor_seating', True),
                'delivery_available': restaurant.get('delivery_available', False),
                'takeout_available': restaurant.get('takeout_available', True),
                'chef_info': get_chef_info(budget_range),
                'awards': get_restaurant_awards(budget_range),
                'booking_info': {
                    'advance_booking_required': party_size > 6,
                    'cancellation_policy': '24 hours notice required',
                    'deposit_required': budget_range in ['high', 'luxury'] and party_size > 8
                }
            }
            
            processed_restaurants.append(processed_restaurant)
            logger.debug(f"  ✅ Processed {restaurant_name} - ${adjusted_price} avg, {processed_restaurant['rating']}⭐")
        
        # Log processing summary
        logger.info(f"📊 Processing Summary:")
        logger.info(f"  - Restaurants processed: {len(restaurants[:10])}")
        logger.info(f"  - Restaurants skipped (capacity): {skipped_restaurants}")
        logger.info(f"  - Restaurants included: {len(processed_restaurants)}")
        
        # Sort by rating (highest first)
        logger.info(f"Sorting {len(processed_restaurants)} restaurants by rating...")
        processed_restaurants.sort(key=lambda x: x['rating'], reverse=True)
        
        if processed_restaurants:
            highest_rated = processed_restaurants[0]
            lowest_rated = processed_restaurants[-1]
            rating_range = f"{lowest_rated['rating']:.1f} - {highest_rated['rating']:.1f}"
            logger.info(f"✅ Rating range after sorting: {rating_range}")
            logger.info(f"  Highest rated: {highest_rated['name']} - {highest_rated['rating']}⭐")
            logger.info(f"  Lowest rated: {lowest_rated['name']} - {lowest_rated['rating']}⭐")
        
        # Final summary logging
        logger.info(f"=== DYNAMODB SEARCH COMPLETE ===")
        logger.info(f"🍽️ Search Results Summary:")
        logger.info(f"  - Destination: {destination}")
        logger.info(f"  - Date/Time: {date} at {time}")
        logger.info(f"  - Cuisine: {cuisine}")
        logger.info(f"  - Budget range: {budget_range} (multiplier: {multiplier})")
        logger.info(f"  - Party size: {party_size}")
        logger.info(f"  - Restaurants found: {len(processed_restaurants)}")
        
        if processed_restaurants:
            avg_price = sum(r['average_price'] for r in processed_restaurants) / len(processed_restaurants)
            avg_rating = sum(r['rating'] for r in processed_restaurants) / len(processed_restaurants)
            logger.info(f"  - Average price: ${avg_price:.2f}")
            logger.info(f"  - Average rating: {avg_rating:.1f}⭐")
            
            # Log top 3 restaurants
            logger.info(f"  - Top 3 restaurants by rating:")
            for i, restaurant in enumerate(processed_restaurants[:3], 1):
                logger.info(f"    {i}. {restaurant['name']} - ${restaurant['average_price']} avg ({restaurant['rating']}⭐)")
        
        logger.info(f"Returning {len(processed_restaurants)} processed restaurants")
        return processed_restaurants
        
    except Exception as e:
        logger.error(f"❌ Error querying DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB error traceback:")
        logger.error(f"=== DYNAMODB SEARCH FAILED ===")
        # Return empty list if DynamoDB query fails
        return []

def get_price_range(average_price: int) -> str:
    """Get price range category based on average price"""
    if average_price < 25:
        return '$'
    elif average_price < 50:
        return '$$'
    elif average_price < 100:
        return '$$$'
    else:
        return '$$$$'

def get_restaurant_hours(cuisine: str) -> Dict[str, str]:
    """Get typical opening hours based on cuisine type"""
    hours_by_cuisine = {
        'breakfast': {'weekdays': '6:00 AM - 11:00 AM', 'weekends': '7:00 AM - 12:00 PM'},
        'lunch': {'weekdays': '11:00 AM - 3:00 PM', 'weekends': '11:00 AM - 4:00 PM'},
        'dinner': {'weekdays': '5:00 PM - 10:00 PM', 'weekends': '5:00 PM - 11:00 PM'},
        'cafe': {'weekdays': '7:00 AM - 6:00 PM', 'weekends': '8:00 AM - 7:00 PM'},
        'bar': {'weekdays': '4:00 PM - 12:00 AM', 'weekends': '2:00 PM - 2:00 AM'},
        'fast_food': {'weekdays': '6:00 AM - 11:00 PM', 'weekends': '7:00 AM - 12:00 AM'}
    }
    
    return hours_by_cuisine.get(cuisine.lower(), {'weekdays': '11:00 AM - 10:00 PM', 'weekends': '11:00 AM - 11:00 PM'})

def get_dress_code(budget_range: str) -> str:
    """Get dress code based on budget range"""
    dress_codes = {
        'low': 'Casual',
        'medium': 'Smart Casual',
        'high': 'Business Casual',
        'luxury': 'Formal / Business Attire'
    }
    
    return dress_codes.get(budget_range, 'Smart Casual')

def get_dietary_options(cuisine: str) -> List[str]:
    """Get dietary options based on cuisine type"""
    base_options = ['Vegetarian Options']
    
    cuisine_options = {
        'italian': ['Gluten-Free Pasta', 'Vegan Options'],
        'asian': ['Vegan Options', 'Gluten-Free Options'],
        'indian': ['Vegan Options', 'Dairy-Free Options'],
        'mediterranean': ['Vegan Options', 'Gluten-Free Options'],
        'american': ['Gluten-Free Options', 'Low-Carb Options'],
        'french': ['Gluten-Free Options'],
        'mexican': ['Vegan Options', 'Gluten-Free Options']
    }
    
    options = base_options.copy()
    options.extend(cuisine_options.get(cuisine.lower(), ['Gluten-Free Options']))
    
    return list(set(options))  # Remove duplicates

def get_restaurant_amenities(budget_range: str) -> List[str]:
    """Get amenities based on budget range"""
    base_amenities = ['WiFi', 'Restrooms', 'Air Conditioning']
    
    budget_amenities = {
        'low': ['Counter Service', 'Takeout'],
        'medium': ['Table Service', 'Bar', 'Outdoor Seating'],
        'high': ['Full Bar', 'Private Dining', 'Sommelier', 'Coat Check'],
        'luxury': ['Concierge', 'Valet Parking', 'Private Chef', 'Wine Cellar']
    }
    
    amenities = base_amenities.copy()
    amenities.extend(budget_amenities.get(budget_range, budget_amenities['medium']))
    
    return amenities

def get_special_features(cuisine: str, budget_range: str) -> List[str]:
    """Get special features based on cuisine and budget"""
    features = []
    
    cuisine_features = {
        'italian': ['Wood-fired Pizza Oven', 'Fresh Pasta Made Daily'],
        'asian': ['Sushi Bar', 'Teppanyaki Grill'],
        'indian': ['Tandoor Oven', 'Spice Market'],
        'french': ['Wine Cellar', 'Chef\'s Table'],
        'american': ['Craft Beer Selection', 'Local Ingredients'],
        'mexican': ['Tequila Bar', 'Fresh Guacamole Station']
    }
    
    budget_features = {
        'luxury': ['Michelin Star Chef', 'Exclusive Wine Pairings', 'Personal Sommelier'],
        'high': ['Chef\'s Tasting Menu', 'Premium Wine Selection', 'Live Music'],
        'medium': ['Daily Specials', 'Happy Hour', 'Weekend Brunch'],
        'low': ['Quick Service', 'Family Portions', 'Kids Menu']
    }
    
    features.extend(cuisine_features.get(cuisine.lower(), []))
    features.extend(budget_features.get(budget_range, []))
    
    return features

def get_popular_dishes(cuisine: str) -> List[str]:
    """Get popular dishes based on cuisine type"""
    dishes_by_cuisine = {
        'italian': ['Margherita Pizza', 'Spaghetti Carbonara', 'Osso Buco', 'Tiramisu'],
        'french': ['Coq au Vin', 'Bouillabaisse', 'Ratatouille', 'Crème Brûlée'],
        'asian': ['Pad Thai', 'Sushi Platter', 'Kung Pao Chicken', 'Miso Soup'],
        'indian': ['Butter Chicken', 'Biryani', 'Tandoori Lamb', 'Gulab Jamun'],
        'mexican': ['Tacos al Pastor', 'Mole Poblano', 'Ceviche', 'Churros'],
        'american': ['Grilled Steak', 'BBQ Ribs', 'Caesar Salad', 'Apple Pie'],
        'mediterranean': ['Grilled Octopus', 'Moussaka', 'Hummus Platter', 'Baklava']
    }
    
    return dishes_by_cuisine.get(cuisine.lower(), ['Chef\'s Special', 'Seasonal Menu', 'House Signature'])

def get_chef_info(budget_range: str) -> Dict[str, str]:
    """Get chef information based on budget range"""
    if budget_range == 'luxury':
        return {
            'name': 'Chef Michel Laurent',
            'experience': '20+ years',
            'specialties': 'French cuisine, molecular gastronomy',
            'awards': 'Michelin Star, James Beard Award'
        }
    elif budget_range == 'high':
        return {
            'name': 'Chef Sarah Johnson',
            'experience': '15+ years',
            'specialties': 'Farm-to-table, seasonal menus',
            'awards': 'Local culinary awards'
        }
    else:
        return {
            'name': 'Head Chef',
            'experience': '10+ years',
            'specialties': 'Traditional recipes',
            'awards': 'Local recognition'
        }

def get_restaurant_awards(budget_range: str) -> List[str]:
    """Get restaurant awards based on budget range"""
    awards_by_budget = {
        'luxury': ['Michelin Star', 'AAA Five Diamond', 'James Beard Award', 'Wine Spectator Grand Award'],
        'high': ['Michelin Bib Gourmand', 'AAA Four Diamond', 'Local Best Restaurant', 'Wine Spectator Award'],
        'medium': ['TripAdvisor Certificate of Excellence', 'Local Favorite', 'Best Value Award'],
        'low': ['Community Choice Award', 'Best Local Eats']
    }
    
    return awards_by_budget.get(budget_range, [])