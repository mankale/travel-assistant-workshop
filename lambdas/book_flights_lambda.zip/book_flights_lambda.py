def lambda_handler(event, context):
    return {"statusCode": 200, "body": "Flights are booked successfully"}
