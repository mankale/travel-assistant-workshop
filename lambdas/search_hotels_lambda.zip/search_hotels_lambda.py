import json
import boto3
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from decimal import Decimal

def decimal_default(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Configure comprehensive logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# Create formatter for detailed logs
formatter = logging.Formatter('[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s')
# Ensure handler exists
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def lambda_handler(event, context):
    """
    MCP-compatible Lambda function for hotel search
    
    Expected input format:
    {
        "body": "{\"destination\": \"Paris\", \"check_in\": \"2024-12-15\", \"check_out\": \"2024-12-22\", \"guests\": 2, \"budget_range\": \"medium\"}"
    }
    """
    
    # Log the incoming event for debugging
    logger.info("=== LAMBDA INVOCATION START ===")
    logger.info(f"Raw event received: {json.dumps(event, default=str)}")
    logger.info(f"Context: {context}")
    logger.info(f"Function name: {context.function_name if context else 'Unknown'}")
    logger.info(f"Request ID: {context.aws_request_id if context else 'Unknown'}")
    logger.info(f"Remaining time: {context.get_remaining_time_in_millis() if context else 'Unknown'}ms")
    
    try:
        # Parse the incoming event with detailed logging
        logger.info("Step 1: Parsing incoming event...")
        
        # Handle different event formats - API Gateway vs Direct Lambda invocation
        body = {}
        
        # Check if this is a direct Lambda invocation (parameters directly in event)
        if 'destination' in event and 'check_in' in event:
            logger.info("Direct Lambda invocation detected - using event as body")
            body = event
            logger.info(f"Direct invocation body: {body}")
        
        # Check if this is API Gateway format (body field)
        elif event.get('body') is not None:
            if isinstance(event.get('body'), str):
                logger.info(f"API Gateway format - Event body is string: {event['body']}")
                if event['body'].strip():  # Check if not empty string
                    body = json.loads(event['body'])
                    logger.info(f"Parsed API Gateway body: {body}")
                else:
                    logger.warning("Event body is empty string")
                    body = {}
            elif isinstance(event.get('body'), dict):
                logger.info("API Gateway format - Event body is already a dict")
                body = event['body']
            else:
                logger.warning(f"Event body is unexpected type: {type(event.get('body'))}")
                body = event.get('body', {}) if event.get('body') is not None else {}
        
        # No body found in either format
        else:
            logger.warning("No request body found in either direct or API Gateway format")
            body = {}
        
        # Extract hotel search parameters with detailed logging
        logger.info("Step 2: Extracting search parameters...")
        
        destination = body.get('destination', '')
        check_in = body.get('check_in', '')
        check_out = body.get('check_out', '')
        guests = body.get('guests', 1)
        budget_range = body.get('budget_range', 'medium')
        rooms = body.get('rooms', 1)
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - destination: '{destination}'")
        logger.info(f"  - check_in: '{check_in}'")
        logger.info(f"  - check_out: '{check_out}'")
        logger.info(f"  - guests: {guests}")
        logger.info(f"  - budget_range: '{budget_range}'")
        logger.info(f"  - rooms: {rooms}")
        
        logger.info(f"Hotel search request: {destination}, {check_in} to {check_out}, {guests} guests, {budget_range} budget")
        
        # Validate required parameters with detailed logging
        logger.info("Step 3: Validating required parameters...")
        
        missing_params = []
        if not destination:
            missing_params.append('destination')
        if not check_in:
            missing_params.append('check_in')
        if not check_out:
            missing_params.append('check_out')
            
        if missing_params:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameters',
                    'missing': missing_params,
                    'required': ['destination', 'check_in', 'check_out'],
                    'received': body
                }, default=decimal_default)
            }
            logger.error(f"Validation failed - missing parameters: {missing_params}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
        logger.info("✅ All required parameters validated successfully")
        
        # Calculate number of nights with detailed logging
        logger.info("Step 4: Calculating nights and validating dates...")
        
        try:
            logger.info(f"Parsing check-in date: {check_in}")
            check_in_date = datetime.strptime(check_in, '%Y-%m-%d')
            logger.info(f"Parsed check-in: {check_in_date}")
            
            logger.info(f"Parsing check-out date: {check_out}")
            check_out_date = datetime.strptime(check_out, '%Y-%m-%d')
            logger.info(f"Parsed check-out: {check_out_date}")
            
            nights = (check_out_date - check_in_date).days
            logger.info(f"Calculated nights: {nights}")
            
            if nights <= 0:
                error_response = {
                    'statusCode': 400,
                    'body': json.dumps({
                        'error': 'Check-out date must be after check-in date',
                        'check_in': check_in,
                        'check_out': check_out,
                        'nights_calculated': nights
                    }, default=decimal_default)
                }
                logger.error(f"Invalid date range - nights: {nights}")
                logger.error(f"Returning error response: {error_response}")
                return error_response
        except ValueError as e:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Invalid date format. Use YYYY-MM-DD',
                    'details': str(e)
                }, default=decimal_default)
            }
        
        # Search hotels from DynamoDB synthetic data
        logger.info("Step 5: Starting hotel search from DynamoDB...")
        hotels = search_hotels_from_dynamodb(destination, check_in, check_out, guests, budget_range, nights)
        logger.info(f"Hotel search completed - found {len(hotels)} hotels")
        
        # Return MCP-compatible response
        response_body = {
            'hotels': hotels,
            'search_params': {
                'destination': destination,
                'check_in': check_in,
                'check_out': check_out,
                'guests': guests,
                'budget_range': budget_range,
                'nights': nights
            },
            'total_results': len(hotels)
        }
        
        response = {
            'statusCode': 200,
            'body': json.dumps(response_body, default=decimal_default)
        }
        
        logger.info(f"✅ Hotel search completed successfully: {len(hotels)} results found")
        logger.info(f"Response body size: {len(json.dumps(response_body, default=decimal_default))} characters")
        logger.info("=== LAMBDA INVOCATION SUCCESS ===")
        return response
        
    except json.JSONDecodeError as e:
        error_response = {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body',
                'details': str(e),
                'received_body': event.get('body', 'No body')
            }, default=decimal_default)
        }
        logger.error(f"❌ JSON decode error: {str(e)}")
        logger.error(f"Raw body that failed to parse: {event.get('body', 'No body')}")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (JSON) ===")
        return error_response
    
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full exception traceback:")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (EXCEPTION) ===")
        return error_response

def search_hotels_from_dynamodb(destination: str, check_in: str, check_out: str, guests: int, budget_range: str, nights: int) -> List[Dict]:
    """
    Search hotels from DynamoDB synthetic data
    """
    logger.info(f"=== DYNAMODB SEARCH START ===")
    logger.info(f"Search parameters: destination={destination}, guests={guests}, budget={budget_range}, nights={nights}")
    
    # Initialize DynamoDB resource
    logger.info("Initializing DynamoDB resource...")
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('synthetic-hotels')
        logger.info("✅ DynamoDB resource initialized successfully")
        logger.info(f"Table name: {table.table_name}")
        
        # Validate table exists and is accessible
        logger.debug("Validating table accessibility...")
        table_status = table.table_status
        logger.info(f"Table status: {table_status}")
        
        if table_status != 'ACTIVE':
            logger.warning(f"⚠️ Table status is {table_status}, not ACTIVE")
        
        # Log table metadata
        logger.debug(f"Table creation date: {table.creation_date_time}")
        logger.debug(f"Table item count: {table.item_count}")
        
    except Exception as e:
        logger.error(f"❌ Failed to initialize DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB initialization error:")
        raise e
    
    try:
        # Query using GSI for city
        logger.info(f"Querying DynamoDB for city: {destination}")
        logger.info("Using CityIndex GSI...")
        
        query_params = {
            'IndexName': 'CityIndex',
            'KeyConditionExpression': 'city = :city',
            'ExpressionAttributeValues': {
                ':city': destination
            }
        }
        logger.info(f"Query parameters: {query_params}")
        
        response = table.query(**query_params)
        logger.info(f"DynamoDB query response: Count={response.get('Count', 0)}, ScannedCount={response.get('ScannedCount', 0)}")
        
        hotels = response.get('Items', [])
        logger.info(f"Found {len(hotels)} hotels for city: {destination}")
        
        # If no hotels found for exact city, get sample hotels and modify them
        if not hotels:
            logger.warning(f"No hotels found for {destination}, falling back to sample data")
            logger.info("Performing table scan for sample hotels...")
            
            scan_response = table.scan(Limit=10)
            hotels = scan_response.get('Items', [])
            logger.info(f"Scan returned {len(hotels)} sample hotels")
            
            # Modify sample hotels to match the search criteria
            logger.info(f"Modifying sample hotels to match destination: {destination}")
            for hotel in hotels:
                original_city = hotel.get('city', 'Unknown')
                hotel['city'] = destination
                logger.debug(f"Modified hotel {hotel.get('hotel_id', 'unknown')} city: {original_city} → {destination}")
        else:
            logger.info(f"✅ Found {len(hotels)} hotels directly for {destination}")
            # Log some sample hotel details
            for i, hotel in enumerate(hotels[:3], 1):
                hotel_name = hotel.get('name', 'Unknown')
                hotel_id = hotel.get('hotel_id', 'Unknown')
                base_price = hotel.get('price_per_night', 0)
                logger.debug(f"  {i}. {hotel_name} (ID: {hotel_id}) - Base price: ${base_price}/night")
        
        # Apply budget filtering and sorting
        logger.info(f"Applying budget filtering for range: {budget_range}")
        budget_multipliers = {
            'low': 0.6,
            'medium': 1.0,
            'high': 1.8,
            'luxury': 3.0
        }
        
        multiplier = budget_multipliers.get(budget_range.lower(), 1.0)
        logger.info(f"Budget multiplier: {multiplier}")
        
        # Filter and enhance hotels based on search criteria
        logger.info(f"Processing up to 10 hotels from {len(hotels)} available")
        processed_hotels = []
        skipped_hotels = 0
        
        for i, hotel in enumerate(hotels[:10]):  # Limit to 10 results
            hotel_id = hotel.get('hotel_id', f'unknown_{i}')
            hotel_name = hotel.get('name', 'Unknown Hotel')
            logger.debug(f"Processing hotel {i+1}: {hotel_name} (ID: {hotel_id})")
            
            # Convert Decimal to int/float for JSON serialization
            original_price = float(hotel.get('price_per_night', 120))
            adjusted_price_per_night = int(original_price * multiplier)
            total_price = adjusted_price_per_night * nights
            
            logger.debug(f"  Price calculation: ${original_price} × {multiplier} = ${adjusted_price_per_night}/night")
            logger.debug(f"  Total price: ${adjusted_price_per_night} × {nights} nights = ${total_price}")
            
            # Check if hotel can accommodate guests
            max_occupancy = hotel.get('max_occupancy', 2)
            if guests > max_occupancy:
                logger.debug(f"  ⚠️ Skipping {hotel_name}: guests ({guests}) > max_occupancy ({max_occupancy})")
                skipped_hotels += 1
                continue  # Skip hotels that can't accommodate the guest count
            
            logger.debug(f"  ✅ Hotel can accommodate {guests} guests (max: {max_occupancy})")
            
            processed_hotel = {
                'hotel_id': hotel.get('hotel_id', f"HT{len(processed_hotels)+1:04d}"),
                'name': hotel.get('name', f"Hotel {destination}"),
                'chain': hotel.get('chain', 'Independent'),
                'city': destination,
                'address': hotel.get('address', f"Main Street, {destination}"),
                'rating': float(hotel.get('rating', 3.5)),
                'check_in': check_in,
                'check_out': check_out,
                'nights': nights,
                'guests': guests,
                'price_per_night': adjusted_price_per_night,
                'total_price': total_price,
                'currency': hotel.get('currency', 'USD'),
                'room_type': hotel.get('room_type', get_room_type(guests, budget_range)),
                'max_occupancy': max_occupancy,
                'beds_count': hotel.get('beds_count', 1),
                'family_friendly': hotel.get('family_friendly', False),
                'kids_club': hotel.get('kids_club', False),
                'pool': hotel.get('pool', False),
                'playground': hotel.get('playground', False),
                'loyalty_program': hotel.get('loyalty_program', f"{hotel.get('chain', 'Hotel')} Rewards"),
                'loyalty_benefits': hotel.get('loyalty_benefits', {
                    'member': ['Free WiFi'],
                    'gold': ['Free WiFi', 'Late Checkout'],
                    'platinum': ['Free WiFi', 'Late Checkout', 'Free Breakfast']
                }),
                'points_earned': hotel.get('points_earned', 100),
                'wifi_free': hotel.get('wifi_free', True),
                'breakfast_included': hotel.get('breakfast_included', False),
                'parking_available': hotel.get('parking_available', False),
                'gym': hotel.get('gym', False),
                'amenities': [],
                'services': [],
                'policies': {
                    'cancellation': 'Free cancellation until 24h before check-in' if budget_range.lower() in ['high', 'luxury'] else 'Standard cancellation policy',
                    'pets': 'Pet-friendly' if hotel.get('family_friendly', False) else 'No pets allowed',
                    'smoking': 'Non-smoking rooms available'
                },
                'ratings': {
                    'overall': float(hotel.get('rating', 3.5)),
                    'cleanliness': float(hotel.get('rating', 3.5)) + 0.2,
                    'service': float(hotel.get('rating', 3.5)) + 0.1,
                    'location': float(hotel.get('rating', 3.5)) + 0.3,
                    'value': float(hotel.get('rating', 3.5)) - 0.1
                },
                'reviews_count': 150 + len(processed_hotels) * 25,
                'booking_url': f"https://example-hotels.com/book/{hotel.get('hotel_id', 'unknown')}",
                'images': [
                    f"https://example-hotels.com/images/{hotel.get('hotel_id', 'default')}/exterior.jpg",
                    f"https://example-hotels.com/images/{hotel.get('hotel_id', 'default')}/room.jpg",
                    f"https://example-hotels.com/images/{hotel.get('hotel_id', 'default')}/lobby.jpg"
                ],
                'business_friendly': hotel.get('chain') in ['Marriott', 'Hilton', 'Hyatt'],
                'accessibility': {
                    'wheelchair_accessible': float(hotel.get('rating', 3.5)) >= 3.0,
                    'elevator': True,
                    'accessible_parking': hotel.get('parking_available', False)
                }
            }
            
            # Add amenities based on hotel data
            if processed_hotel['wifi_free']:
                processed_hotel['amenities'].append('Free WiFi')
            if processed_hotel['breakfast_included']:
                processed_hotel['amenities'].append('Breakfast Included')
            if processed_hotel['pool']:
                processed_hotel['amenities'].append('Swimming Pool')
            if processed_hotel['gym']:
                processed_hotel['amenities'].append('Fitness Center')
            if processed_hotel['kids_club']:
                processed_hotel['amenities'].append('Kids Club')
            if processed_hotel['playground']:
                processed_hotel['amenities'].append('Playground')
            if processed_hotel['parking_available']:
                processed_hotel['amenities'].append('Parking')
            
            # Add services based on hotel rating and chain
            processed_hotel['services'] = ['Housekeeping', 'Front Desk', '24/7 Reception']
            if processed_hotel['rating'] >= 4.0:
                processed_hotel['services'].extend(['Concierge', 'Room Service', 'Laundry Service'])
            if processed_hotel['business_friendly']:
                processed_hotel['services'].extend(['Business Center', 'Meeting Rooms'])
            
            processed_hotels.append(processed_hotel)
        
        # Log processing summary
        logger.info(f"📊 Processing Summary:")
        logger.info(f"  - Hotels processed: {len(hotels[:10])}")
        logger.info(f"  - Hotels skipped (capacity): {skipped_hotels}")
        logger.info(f"  - Hotels included: {len(processed_hotels)}")
        
        # Sort by price
        logger.info(f"Sorting {len(processed_hotels)} hotels by price...")
        processed_hotels.sort(key=lambda x: x['price_per_night'])
        
        if processed_hotels:
            cheapest = processed_hotels[0]
            most_expensive = processed_hotels[-1]
            price_range = f"${cheapest['price_per_night']} - ${most_expensive['price_per_night']}"
            logger.info(f"✅ Price range after sorting: {price_range}")
            logger.info(f"  Cheapest: {cheapest['name']} - ${cheapest['price_per_night']}/night")
            logger.info(f"  Most expensive: {most_expensive['name']} - ${most_expensive['price_per_night']}/night")
        
        # Final summary logging
        logger.info(f"=== DYNAMODB SEARCH COMPLETE ===")
        logger.info(f"🏨 Search Results Summary:")
        logger.info(f"  - Destination: {destination}")
        logger.info(f"  - Date range: {check_in} to {check_out} ({nights} nights)")
        logger.info(f"  - Guests: {guests}")
        logger.info(f"  - Budget range: {budget_range} (multiplier: {multiplier})")
        logger.info(f"  - Hotels found: {len(processed_hotels)}")
        
        if processed_hotels:
            avg_price = sum(h['price_per_night'] for h in processed_hotels) / len(processed_hotels)
            logger.info(f"  - Average price: ${avg_price:.2f}/night")
            
            # Log top 3 hotels
            logger.info(f"  - Top 3 hotels by price:")
            for i, hotel in enumerate(processed_hotels[:3], 1):
                logger.info(f"    {i}. {hotel['name']} - ${hotel['price_per_night']}/night ({hotel['rating']}⭐)")
        
        logger.info(f"Returning {len(processed_hotels)} processed hotels")
        return processed_hotels
        
    except Exception as e:
        logger.error(f"❌ Error querying DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB error traceback:")
        logger.error(f"=== DYNAMODB SEARCH FAILED ===")
        # Return empty list if DynamoDB query fails
        return []

def get_room_type(guests: int, budget_range: str) -> str:
    """Determine appropriate room type based on guests and budget"""
    logger.debug(f"Determining room type for {guests} guests, budget: {budget_range}")
    
    if guests == 1:
        room_type = 'Single Room' if budget_range.lower() == 'low' else 'Deluxe Single'
    elif guests == 2:
        if budget_range.lower() in ['luxury', 'high']:
            room_type = 'Executive Suite'
        else:
            room_type = 'Double Room'
    elif guests <= 4:
        room_type = 'Family Suite' if budget_range.lower() in ['high', 'luxury'] else 'Family Room'
    else:
        room_type = 'Large Family Suite'
    
    logger.debug(f"Selected room type: {room_type}")
    return room_type

def get_hotel_amenities(category: str, budget_range: str) -> List[str]:
    """Get amenities based on hotel category and budget range"""
    base_amenities = ['WiFi', 'Air Conditioning', '24/7 Reception']
    
    category_amenities = {
        'luxury': ['Spa', 'Fine Dining Restaurant', 'Concierge', 'Valet Parking', 'Room Service'],
        'business': ['Business Center', 'Meeting Rooms', 'Express Check-in/out', 'Laundry Service'],
        'family': ['Kids Club', 'Family Pool', 'Playground', 'Babysitting Service'],
        'budget': ['Continental Breakfast', 'Luggage Storage'],
        'boutique': ['Unique Design', 'Local Art', 'Personalized Service', 'Rooftop Terrace']
    }
    
    budget_amenities = {
        'luxury': ['Butler Service', 'Private Beach Access', 'Helicopter Landing'],
        'high': ['Premium Bedding', 'Minibar', 'Balcony'],
        'medium': ['Fitness Center', 'Restaurant', 'Bar'],
        'low': ['Shared Kitchen', 'Common Area']
    }
    
    amenities = base_amenities.copy()
    amenities.extend(category_amenities.get(category, []))
    amenities.extend(budget_amenities.get(budget_range.lower(), []))
    
    return list(set(amenities))  # Remove duplicates

def get_hotel_services(category: str) -> List[str]:
    """Get services based on hotel category"""
    base_services = ['Housekeeping', 'Front Desk', 'Luggage Assistance']
    
    category_services = {
        'luxury': ['Personal Butler', 'Limousine Service', 'Private Chef'],
        'business': ['Airport Shuttle', 'Printing Services', 'Translation Services'],
        'family': ['Child Care', 'Activity Planning', 'Equipment Rental'],
        'budget': ['Self-Service Laundry', 'Tourist Information'],
        'boutique': ['Local Experience Curation', 'Art Tours', 'Wine Tasting']
    }
    
    services = base_services.copy()
    services.extend(category_services.get(category, []))
    
    return services

