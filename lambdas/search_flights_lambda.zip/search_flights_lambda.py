import json
import boto3
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from decimal import Decimal

def decimal_default(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Configure comprehensive logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# Create formatter for detailed logs
formatter = logging.Formatter('[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s')
# Ensure handler exists
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

def lambda_handler(event, context):
    """
    MCP-compatible Lambda function for flight search
    
    Expected input format:
    {
        "body": "{\"origin\": \"NYC\", \"destination\": \"PAR\", \"departure_date\": \"2024-12-15\", \"passengers\": 2, \"budget_range\": \"medium\"}"
    }
    """
    
    # Log the incoming event for debugging
    logger.info("=== LAMBDA INVOCATION START ===")
    logger.info(f"Raw event received: {json.dumps(event, default=str)}")
    logger.info(f"Context: {context}")
    
    try:
        # Parse the incoming event with detailed logging
        logger.info("Parsing incoming event...")
        
        # Handle different event formats - API Gateway vs Direct Lambda invocation
        body = {}
        
        # Check if this is a direct Lambda invocation (parameters directly in event)
        if 'origin' in event and 'destination' in event:
            logger.info("Direct Lambda invocation detected - using event as body")
            body = event
            logger.info(f"Direct invocation body: {body}")
        
        # Check if this is API Gateway format (body field)
        elif event.get('body') is not None:
            if isinstance(event.get('body'), str):
                logger.info(f"API Gateway format - Event body is string: {event['body']}")
                if event['body'].strip():  # Check if not empty string
                    body = json.loads(event['body'])
                    logger.info(f"Parsed API Gateway body: {body}")
                else:
                    logger.warning("Event body is empty string")
                    body = {}
            elif isinstance(event.get('body'), dict):
                logger.info("API Gateway format - Event body is already a dict")
                body = event['body']
            else:
                logger.warning(f"Event body is unexpected type: {type(event.get('body'))}")
                body = event.get('body', {}) if event.get('body') is not None else {}
        
        # No body found in either format
        else:
            logger.warning("No request body found in either direct or API Gateway format")
            body = {}
        
        # Extract flight search parameters with validation logging
        origin = body.get('origin', '')
        destination = body.get('destination', '')
        departure_date = body.get('departure_date', '')
        passengers = body.get('passengers', 1)
        budget_range = body.get('budget_range', 'medium')
        
        logger.info(f"Extracted parameters:")
        logger.info(f"  - origin: '{origin}'")
        logger.info(f"  - destination: '{destination}'")
        logger.info(f"  - departure_date: '{departure_date}'")
        logger.info(f"  - passengers: {passengers}")
        logger.info(f"  - budget_range: '{budget_range}'")
        
        logger.info(f"Flight search request: {origin} -> {destination}, {departure_date}, {passengers} passengers, {budget_range} budget")
        
        # Validate required parameters with detailed logging
        logger.info("Validating required parameters...")
        missing_params = []
        if not origin:
            missing_params.append('origin')
        if not destination:
            missing_params.append('destination')
        if not departure_date:
            missing_params.append('departure_date')
            
        if missing_params:
            error_response = {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required parameters',
                    'missing': missing_params,
                    'required': ['origin', 'destination', 'departure_date'],
                    'received': body
                }, default=decimal_default)
            }
            logger.error(f"Validation failed - missing parameters: {missing_params}")
            logger.error(f"Returning error response: {error_response}")
            return error_response
            
        logger.info("✅ All required parameters validated successfully")
        
        # Search flights from DynamoDB synthetic data
        logger.info("Starting flight search from DynamoDB...")
        flights = search_flights_from_dynamodb(origin, destination, departure_date, passengers, budget_range)
        logger.info(f"Flight search completed - found {len(flights)} flights")
        
        # Return MCP-compatible response
        response_body = {
            'flights': flights,
            'search_params': {
                'origin': origin,
                'destination': destination,
                'departure_date': departure_date,
                'passengers': passengers,
                'budget_range': budget_range
            },
            'total_results': len(flights)
        }
        
        response = {
            'statusCode': 200,
            'body': json.dumps(response_body, default=decimal_default)
        }
        
        logger.info(f"✅ Flight search completed successfully: {len(flights)} results found")
        logger.info(f"Response body size: {len(json.dumps(response_body, default=decimal_default))} characters")
        logger.info("=== LAMBDA INVOCATION SUCCESS ===")
        return response
        
    except json.JSONDecodeError as e:
        error_response = {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Invalid JSON in request body',
                'details': str(e),
                'received_body': event.get('body', 'No body')
            }, default=decimal_default)
        }
        logger.error(f"❌ JSON decode error: {str(e)}")
        logger.error(f"Raw body that failed to parse: {event.get('body', 'No body')}")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (JSON) ===")
        return error_response
    
    except Exception as e:
        error_response = {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e),
                'type': type(e).__name__
            }, default=decimal_default)
        }
        logger.error(f"❌ Unexpected error: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full exception traceback:")
        logger.error(f"Returning error response: {error_response}")
        logger.error("=== LAMBDA INVOCATION FAILED (EXCEPTION) ===")
        return error_response

def search_flights_from_dynamodb(origin: str, destination: str, departure_date: str, passengers: int, budget_range: str) -> List[Dict]:
    """
    Search flights from DynamoDB synthetic data
    """
    logger.info(f"=== DYNAMODB SEARCH START ===")
    logger.info(f"Search parameters: {origin} -> {destination}, passengers={passengers}, budget={budget_range}")
    
    # Initialize DynamoDB resource
    logger.info("Initializing DynamoDB resource...")
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('synthetic-flights')
        logger.info("✅ DynamoDB resource initialized successfully")
        logger.info(f"Table name: {table.table_name}")
    except Exception as e:
        logger.error(f"❌ Failed to initialize DynamoDB: {str(e)}")
        raise e
    
    try:
        # Query using GSI for origin-destination
        origin_destination_key = f"{origin}-{destination}"
        logger.info(f"Searching for route: {origin_destination_key}")
        
        query_params = {
            'IndexName': 'OriginDestinationIndex',
            'KeyConditionExpression': 'origin_destination = :od',
            'ExpressionAttributeValues': {
                ':od': origin_destination_key
            }
        }
        logger.info(f"Query parameters: {query_params}")
        
        response = table.query(**query_params)
        logger.info(f"DynamoDB query response: Count={response.get('Count', 0)}, ScannedCount={response.get('ScannedCount', 0)}")
        
        flights = response.get('Items', [])
        logger.info(f"Found {len(flights)} direct flights for {origin_destination_key}")
        
        # If no direct flights found, try reverse direction or similar airports
        if not flights:
            logger.warning(f"No direct flights found for {origin_destination_key}, trying reverse direction")
            # Try reverse direction
            reverse_key = f"{destination}-{origin}"
            logger.info(f"Searching reverse route: {reverse_key}")
            
            reverse_response = table.query(
                IndexName='OriginDestinationIndex',
                KeyConditionExpression='origin_destination = :od',
                ExpressionAttributeValues={
                    ':od': reverse_key
                }
            )
            flights = reverse_response.get('Items', [])
            logger.info(f"Found {len(flights)} reverse flights for {reverse_key}")
        
        # If still no flights, get some sample flights and modify them
        if not flights:
            logger.warning("No flights found in either direction, falling back to sample data")
            logger.info("Performing table scan for sample flights...")
            
            scan_response = table.scan(Limit=10)
            flights = scan_response.get('Items', [])
            logger.info(f"Scan returned {len(flights)} sample flights")
            
            # Modify sample flights to match the search criteria
            logger.info(f"Modifying sample flights to match route: {origin_destination_key}")
            for flight in flights:
                flight['origin'] = origin
                flight['destination'] = destination
                flight['origin_destination'] = origin_destination_key
                logger.debug(f"Modified flight {flight.get('flight_id', 'unknown')} to route {origin_destination_key}")
        else:
            logger.info(f"✅ Found {len(flights)} flights for route search")
        
        # Apply budget filtering and sorting
        budget_multipliers = {
            'low': 0.7,
            'medium': 1.0,
            'high': 1.5,
            'luxury': 2.0
        }
        
        multiplier = budget_multipliers.get(budget_range.lower(), 1.0)
        
        # Filter and enhance flights based on search criteria
        processed_flights = []
        for flight in flights[:10]:  # Limit to 10 results
            
            # Convert Decimal to int/float for JSON serialization
            original_price = float(flight.get('price', 500))
            adjusted_price = int(original_price * multiplier)
            
            # Parse departure time if it's a datetime string
            departure_time = flight.get('departure_time', departure_date + 'T08:00:00')
            if 'T' in departure_time:
                departure_time = departure_time.split('T')[1][:5]  # Extract time part
            
            # Calculate duration in readable format
            duration_minutes = flight.get('duration_minutes', 360)
            hours = duration_minutes // 60
            minutes = duration_minutes % 60
            duration = f"{hours}h {minutes}m"
            
            processed_flight = {
                'flight_id': flight.get('flight_id', f"FL{len(processed_flights)+1:04d}"),
                'airline': flight.get('airline', 'Unknown Airline'),
                'flight_number': flight.get('flight_number', f"XX{1000 + len(processed_flights)}"),
                'origin': origin,
                'destination': destination,
                'departure_date': departure_date,
                'departure_time': departure_time,
                'duration': duration,
                'duration_minutes': duration_minutes,
                'price': adjusted_price,
                'currency': flight.get('currency', 'USD'),
                'passengers': passengers,
                'total_price': adjusted_price * passengers,
                'seat_class': flight.get('seat_class', 'economy').title(),
                'family_friendly': flight.get('family_friendly', passengers > 1),
                'loyalty_miles': flight.get('loyalty_miles', 0),
                'meal_service': flight.get('meal_service', False),
                'wifi_available': flight.get('wifi_available', False),
                'amenities': [],
                'baggage': {
                    'carry_on': '1 piece',
                    'checked': '1 piece' if budget_range.lower() != 'low' else 'Extra fee'
                },
                'cancellation_policy': 'Flexible' if budget_range.lower() in ['high', 'luxury'] else 'Standard',
                'booking_url': f"https://example-airline.com/book/{flight.get('flight_id', 'unknown')}"
            }
            
            # Add amenities based on flight data and budget
            if processed_flight['wifi_available']:
                processed_flight['amenities'].append('WiFi')
            if processed_flight['meal_service']:
                processed_flight['amenities'].append('Meals')
            if budget_range.lower() in ['high', 'luxury']:
                processed_flight['amenities'].extend(['Premium Seating', 'Priority Boarding'])
            
            processed_flights.append(processed_flight)
        
        # Sort by price
        logger.info(f"Sorting {len(processed_flights)} flights by price...")
        processed_flights.sort(key=lambda x: x['price'])
        
        if processed_flights:
            price_range = f"${processed_flights[0]['price']} - ${processed_flights[-1]['price']}"
            logger.info(f"✅ Price range after sorting: {price_range}")
        
        logger.info(f"=== DYNAMODB SEARCH COMPLETE ===")
        logger.info(f"Returning {len(processed_flights)} processed flights")
        return processed_flights
        
    except Exception as e:
        logger.error(f"❌ Error querying DynamoDB: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.exception("Full DynamoDB error traceback:")
        logger.error(f"=== DYNAMODB SEARCH FAILED ===")
        # Return empty list if DynamoDB query fails
        return []

